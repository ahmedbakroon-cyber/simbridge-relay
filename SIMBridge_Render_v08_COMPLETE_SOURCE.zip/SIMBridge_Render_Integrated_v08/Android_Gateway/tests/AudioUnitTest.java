import com.simbridge.audiolab.PcmJitterBuffer;
import com.simbridge.audiolab.PcmResampler;
public class AudioUnitTest {
 public static void main(String[] args) {
   PcmJitterBuffer b=new PcmJitterBuffer(5);
   byte[] input=new byte[640];input[0]=(byte)0xff;input[1]=0x7f;
   if(b.poll().length!=640)throw new AssertionError("silence size");
   for(int i=0;i<7;i++)b.offer(input);
   if(b.queued()!=5||b.dropped()!=2)throw new AssertionError("bounded jitter");
   if(b.poll().length!=640)throw new AssertionError("packet");
   PcmResampler r=new PcmResampler();
   short[] converted=r.convert(input);
   if(converted.length!=1920)throw new AssertionError("48k stereo 20ms");
   if(converted[4]!=converted[5])throw new AssertionError("stereo channels");
   System.out.println("PASS: jitter queue bounds, drop policy, PCM16 16-to-48k stereo resampler");
 }
}
