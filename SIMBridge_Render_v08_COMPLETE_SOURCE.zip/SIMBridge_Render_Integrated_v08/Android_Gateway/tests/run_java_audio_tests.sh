#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
SRC="$ROOT/app/src/main/java/com/simbridge/audiolab"
javac -d "$TEMP" "$SRC/PcmJitterBuffer.java" "$SRC/PcmResampler.java" "$ROOT/tests/AudioUnitTest.java"
java -cp "$TEMP" AudioUnitTest
