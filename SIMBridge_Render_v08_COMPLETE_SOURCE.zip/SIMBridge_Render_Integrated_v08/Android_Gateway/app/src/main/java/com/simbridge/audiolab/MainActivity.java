package com.simbridge.audiolab;

import android.Manifest;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.widget.EditText;
import android.text.InputType;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioDeviceInfo;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.Base64;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicBoolean running = new AtomicBoolean(false);
    private TextView status;
    private CheckBox consent;
    private AudioRecord recorder;
    private AudioTrack player;
    private File lastDownlink;
    private final int hz = 16000;
    private final AtomicBoolean bridgeOn = new AtomicBoolean(false);
    private volatile SSLSocket bridgeSocket;
    private volatile AudioRecord bridgeRecorder;
    private volatile AudioTrack bridgeTrack;
    private final Object sendLock = new Object();
    private EditText tlsPasswordField;

    private void log(String s) {
        ui.post(() -> {
            String when = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
            status.append("\n[" + when + "] " + s);
        });
    }
    private Button btn(LinearLayout root, String label, View.OnClickListener handler) {
        Button b = new Button(this);
        b.setText(label);
        root.addView(b);
        b.setOnClickListener(handler);
        return b;
    }
    private boolean consented() {
        if (!consent.isChecked()) {
            log("STOP: confirm that this is your own call or all participants consent.");
            return false;
        }
        return true;
    }
    private void permissions() {
        int mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO);
        if (mic != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 51);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(20, 20, 20, 20);
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        TextView header = new TextView(this);
        header.setText("SIM Bridge Redmi Gateway v0.5\nCall audio is sent to your paired iPhone only during a connected cellular call");
        header.setTextSize(17);
        header.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(header);
        consent = new CheckBox(this);
        consent.setText("I own the test call or have the participants' permission.");
        root.addView(consent);
        btn(root, "1 · Inspect permissions / current call mode", v -> inspect());
        btn(root, "2 · Test microphone (3 seconds)", v -> capture(MediaRecorder.AudioSource.MIC, "MIC"));
        btn(root, "3 · Test VOICE_DOWNLINK (3 seconds)", v -> capture(MediaRecorder.AudioSource.VOICE_DOWNLINK, "VOICE_DOWNLINK"));
        btn(root, "4 · Test VOICE_UPLINK (3 seconds)", v -> capture(MediaRecorder.AudioSource.VOICE_UPLINK, "VOICE_UPLINK"));
        btn(root, "5 · Test VOICE_CALL (3 seconds)", v -> capture(MediaRecorder.AudioSource.VOICE_CALL, "VOICE_CALL"));
        btn(root, "6 · Play local speaker tone (2 seconds)", v -> tone());
        btn(root, "7 · Test TELEPHONY TX route (2 seconds)", v -> incallTest());
        btn(root, "8 · SAVE VOICE_DOWNLINK to WAV (3 sec)", v -> saveDownlink());
        btn(root, "9 · PLAY saved WAV (after hanging up)", v -> playDownlink());
        btn(root, "10 · Test Mac WSS connection", v -> connectToMac());
        btn(root, "11 · START live audio bridge", v -> startLiveBridge());
        btn(root, "12 · STOP live audio bridge", v -> stopLiveBridge());
        TextView gatewayLabel = new TextView(this);
        gatewayLabel.setText("\nSIM Bridge v0.5 — Redmi as HTTPS/WSS server (Tailscale)\n" +
                "Keeps Telegram app untouched. Needs a TLS .p12 file generated on your Mac.");
        root.addView(gatewayLabel);
        TextView pairing = new TextView(this);
        pairing.setText("Pairing token (share ONLY with your iPhone):\n" + GatewayConfig.token(this));
        pairing.setTextIsSelectable(true);
        root.addView(pairing);
        btn(root, "Copy pairing token", v -> {
            ClipboardManager clip = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clip.setPrimaryClip(ClipData.newPlainText("SIM Bridge pairing token", GatewayConfig.token(this)));
            log("Pairing token copied. Do not share it publicly.");
        });
        tlsPasswordField = new EditText(this);
        tlsPasswordField.setHint("Password used to export the PKCS12 .p12 certificate");
        tlsPasswordField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(tlsPasswordField);
        btn(root, "13 · Import private HTTPS certificate (.p12)", v -> {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.setType("*/*");
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(picker, 155);
        });
        btn(root, "14 · START Redmi gateway (port 8443)", v -> startRedmiServer());
        btn(root, "15 · STOP Redmi gateway", v -> {
            Intent i = new Intent(this, GatewayService.class).setAction(GatewayService.STOP);
            startService(i);
            log("Gateway stop requested.");
        });
        btn(root, "16 · Gateway status", v -> log(GatewayService.status()));
        btn(root, "STOP test", v -> stop());
        status = new TextView(this);
        status.setTextIsSelectable(true);
        status.setTextSize(13);
        status.setText("Results appear here. Keep this screen open during tests.\nWarning: speaker tone does not test telephony uplink injection.");
        root.addView(status);
        setContentView(scroll);
        permissions();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 155 || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        File tmp = new File(getFilesDir(), "gateway.p12.tmp");
        File dest = new File(getFilesDir(), "gateway.p12");
        try (InputStream in = getContentResolver().openInputStream(data.getData());
             FileOutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new IOException("Could not read selected certificate");
            byte[] bytes = new byte[4096]; int n; long total = 0;
            while ((n = in.read(bytes)) != -1) {
                total += n;
                if (total > 128_000) throw new IOException("Certificate file exceeds 128 KB");
                out.write(bytes, 0, n);
            }
            if (total < 100) throw new IOException("Selected file is too small");
            if (!tmp.renameTo(dest)) throw new IOException("Could not save TLS certificate");
            log("PKCS12 certificate imported securely into app-private storage. Size=" + total);
        } catch (Exception e) { log("Certificate import failed: " + e.getMessage()); tmp.delete(); }
    }

    private void startRedmiServer() {
        if (!consented()) return;
        String[] needed = {Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS};
        java.util.ArrayList<String> missing = new java.util.ArrayList<>();
        for (String permission : needed) if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) missing.add(permission);
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), 56);
            log("Grant the requested permissions and then tap START Redmi gateway again.");
            return;
        }
        stopLiveBridge(); // Never run local server and previous Mac-bridge audio concurrently.
        try {
            String supplied = tlsPasswordField.getText().toString();
            if (!supplied.isEmpty()) GatewayConfig.storePassword(this, supplied);
            else GatewayConfig.password(this); // Verify existing encrypted value.
            tlsPasswordField.setText("");
            Intent command = new Intent(this, GatewayService.class).setAction(GatewayService.START);
            startForegroundService(command);
            log("Redmi server starting. Port 8443. Check status after a few seconds.");
        } catch (Exception e) { log("Gateway setup error: " + e.getMessage()); }
    }

    private void inspect() {
        AudioManager a = (AudioManager) getSystemService(AUDIO_SERVICE);
        int capturePerm = checkSelfPermission("android.permission.CAPTURE_AUDIO_OUTPUT");
        log("SDK=" + Build.VERSION.SDK_INT + ", model=" + Build.MODEL + ", mode=" + a.getMode()
                + " (MODE_IN_CALL=" + AudioManager.MODE_IN_CALL + ")");
        log("RECORD_AUDIO=" + (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED));
        log("CAPTURE_AUDIO_OUTPUT granted to THIS APP=" + (capturePerm == PackageManager.PERMISSION_GRANTED));
        log("MODIFY_PHONE_STATE granted to THIS APP=" + (checkSelfPermission("android.permission.MODIFY_PHONE_STATE") == PackageManager.PERMISSION_GRANTED));
        log("Magisk root does NOT automatically grant privileged framework permissions.");
    }
    private void capture(int source, String name) {
        if (!consented()) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            log("RECORD_AUDIO missing: grant permission first."); permissions(); return;
        }
        if (!running.compareAndSet(false, true)) { log("Another test is running."); return; }
        new Thread(() -> {
            AudioRecord r = null;
            try {
                int min = AudioRecord.getMinBufferSize(hz, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) throw new IllegalStateException("Bad minBufferSize=" + min);
                int size = Math.max(min * 2, 4096);
                log("Opening " + name + " with 16 kHz mono PCM16, buffer=" + size);
                r = new AudioRecord(source, hz, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
                recorder = r;
                if (r.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("AudioRecord not initialized");
                r.startRecording();
                if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("Record not started");
                short[] samples = new short[1024];
                long count = 0, nonzero = 0;
                double squares = 0;
                long end = System.currentTimeMillis() + 3000;
                while (running.get() && System.currentTimeMillis() < end) {
                    int n = r.read(samples, 0, samples.length);
                    if (n < 0) { log(name + " read error=" + n); break; }
                    for (int i = 0; i < n; i++) {
                        if (samples[i] != 0) nonzero++;
                        squares += (double) samples[i] * samples[i];
                    }
                    count += n;
                }
                double rms = count == 0 ? 0 : Math.sqrt(squares / count);
                log(name + " samples=" + count + ", nonzero=" + nonzero + ", RMS=" + String.format(Locale.US,"%.1f",rms));
                if (nonzero == 0) log("ZERO AUDIO is not proof that routing works.");
                else log("Nonzero samples alone do not prove they originate from remote party.");
            } catch (SecurityException e) {
                log(name + " SECURITY DENIED: " + e);
            } catch (Exception e) {
                log(name + " FAILED: " + e);
            } finally {
                if (r != null) { try { r.stop(); } catch (Exception ignored) {} r.release(); }
                recorder = null;
                running.set(false);
            }
        }, "capture-test").start();
    }
    private void saveDownlink() {
        if (!consented()) return;
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audio.getMode() != AudioManager.MODE_IN_CALL) { log("Start a test cellular call before saving downlink."); return; }
        if (!running.compareAndSet(false, true)) { log("Another test is running."); return; }
        new Thread(() -> {
            AudioRecord r = null;
            File output = null;
            try {
                int min = AudioRecord.getMinBufferSize(hz, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) throw new IOException("Invalid buffer: " + min);
                r = new AudioRecord(MediaRecorder.AudioSource.VOICE_DOWNLINK, hz,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, 4096));
                recorder = r;
                if (r.getState() != AudioRecord.STATE_INITIALIZED) throw new IOException("AudioRecord not initialized");
                File dir = getExternalFilesDir(null);
                if (dir == null) throw new IOException("External app files unavailable");
                output = new File(dir, "downlink_test.wav");
                r.startRecording();
                if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IOException("Recording not started");
                short[] buf = new short[1024];
                long samples = 0;
                double sum = 0;
                try (FileOutputStream out = new FileOutputStream(output)) {
                    out.write(new byte[44]); // Standard WAV header written after capture finishes.
                    long end = System.currentTimeMillis() + 3000;
                    byte[] bytes = new byte[2048];
                    while (running.get() && System.currentTimeMillis() < end) {
                        int n = r.read(buf, 0, buf.length);
                        if (n < 0) throw new IOException("AudioRecord read error " + n);
                        for (int i=0; i<n; i++) {
                            int v = buf[i];
                            bytes[i*2] = (byte)v;
                            bytes[i*2+1] = (byte)(v >> 8);
                            sum += (double)v*v;
                        }
                        out.write(bytes, 0, n*2);
                        samples += n;
                    }
                }
                if (samples > Integer.MAX_VALUE / 2 - 44) throw new IOException("Recording too large");
                try (java.io.RandomAccessFile wav = new java.io.RandomAccessFile(output, "rw")) {
                    int dataBytes = (int)(samples * 2);
                    wav.seek(0);
                    wav.writeBytes("RIFF"); le32(wav, dataBytes + 36);
                    wav.writeBytes("WAVEfmt "); le32(wav, 16); le16(wav, 1);
                    le16(wav, 1); le32(wav, hz); le32(wav, hz * 2);
                    le16(wav, 2); le16(wav, 16);
                    wav.writeBytes("data"); le32(wav, dataBytes);
                }
                lastDownlink = output;
                log("Saved WAV locally: " + output.getAbsolutePath());
                log("DOWNLINK samples="+samples+" RMS="+String.format(Locale.US,"%.1f",samples==0?0:Math.sqrt(sum/samples)));
                log("Play AFTER hanging up. Hearing the remote caller is required to confirm downlink.");
            } catch (Exception e) { log("Save DOWNLINK failed: " + e); }
            finally {
                if (r != null) { try {r.stop();}catch(Exception ignored){} r.release(); }
                recorder = null;
                running.set(false);
            }
        }, "save-downlink").start();
    }
    private static void le16(java.io.RandomAccessFile f, int v) throws IOException {
        f.write(v & 255); f.write((v >> 8) & 255);
    }
    private static void le32(java.io.RandomAccessFile f, int v) throws IOException {
        for (int i=0;i<4;i++) f.write((v >> (8*i)) & 255);
    }
    private void playDownlink() {
        if (!consented()) return;
        AudioManager a = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (a.getMode() == AudioManager.MODE_IN_CALL) { log("Hang up before playback to prevent feedback."); return; }
        File wav = lastDownlink == null ? new File(getExternalFilesDir(null), "downlink_test.wav") : lastDownlink;
        if (!wav.exists()) { log("No saved downlink WAV yet."); return; }
        if (!running.compareAndSet(false, true)) { log("Another test is running."); return; }
        new Thread(() -> {
            MediaPlayer mp = new MediaPlayer();
            try {
                mp.setDataSource(wav.getAbsolutePath());
                mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mp.prepare();
                mp.start();
                log("Playing saved DOWNLINK locally; listen for REMOTE participant voice.");
                while (running.get() && mp.isPlaying()) Thread.sleep(100);
            } catch (Exception e) { log("Playback failed: " + e); }
            finally { mp.release(); running.set(false); }
        }, "play-downlink").start();
    }
    private void tone() {
        if (!consented()) return;
        if (!running.compareAndSet(false, true)) { log("Another test is running."); return; }
        new Thread(() -> {
            AudioTrack track = null;
            try {
                int rate = 48000;
                int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(min, rate / 4 * 2)).setTransferMode(AudioTrack.MODE_STREAM).build();
                player = track;
                track.play();
                short[] data = new short[960];
                for (int block = 0; block < 100 && running.get(); block++) {
                    for (int i = 0; i < data.length; i++) {
                        int t = block * data.length + i;
                        data[i] = (short)(Math.sin(2 * Math.PI * 440 * t / rate) * 2500);
                    }
                    int wrote = track.write(data, 0, data.length);
                    if (wrote < 0) { log("AudioTrack write error=" + wrote); break; }
                }
                log("Local 440 Hz speaker test finished. NOT a test of INCALL_MUSIC injection.");
            } catch (Exception e) { log("Tone failed: " + e); }
            finally { if (track != null) { try { track.stop(); } catch (Exception ignored) {} track.release(); } player=null; running.set(false); }
        }, "tone-test").start();
    }
    private void incallTest() {
        if (!consented()) return;
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (audio.getMode() != AudioManager.MODE_IN_CALL) {
            log("STOP: not in a cellular call (MODE_IN_CALL required)."); return;
        }
        if (checkSelfPermission("android.permission.MODIFY_PHONE_STATE") != PackageManager.PERMISSION_GRANTED) {
            log("STOP: MODIFY_PHONE_STATE is not granted. Update privileged allowlist and reboot first."); return;
        }
        AudioDeviceInfo telephony = null;
        for (AudioDeviceInfo d : audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            log("Output device: id=" + d.getId() + " type=" + d.getType() + " name=" + d.getProductName());
            if (d.getType() == AudioDeviceInfo.TYPE_TELEPHONY && d.isSink()) telephony = d;
        }
        if (telephony == null) { log("STOP: TYPE_TELEPHONY output not exposed to this app."); return; }
        if (!running.compareAndSet(false, true)) { log("Another test is running."); return; }
        final AudioDeviceInfo phoneDevice = telephony;
        new Thread(() -> {
            AudioTrack track = null;
            try {
                final int rate = 48000;
                final int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) throw new IllegalStateException("Invalid min buffer=" + min);
                track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                    .setBufferSizeInBytes(Math.max(min * 2, 16384))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
                player = track;
                if (track.getState() != AudioTrack.STATE_INITIALIZED)
                    throw new IllegalStateException("AudioTrack not initialized");
                boolean requested = track.setPreferredDevice(phoneDevice);
                log("Requested TELEPHONY TX device id=" + phoneDevice.getId() + ", accepted=" + requested);
                if (!requested) { log("STOP: preferred telephony route rejected."); return; }
                track.play();
                short[] stereo = new short[960 * 2]; // 20 ms, stereo, 48 kHz
                long written=0;
                for (int block = 0; block < 100 && running.get(); block++) {
                    for (int frame = 0; frame < 960; frame++) {
                        int t = block * 960 + frame;
                        // 660 Hz, 0.6 second tone, then silence; low amplitude
                        short value = t < rate * 0.6 ?
                                (short)(Math.sin(2 * Math.PI * 660 * t / rate) * 1200) : 0;
                        stereo[frame * 2] = value;
                        stereo[frame * 2 + 1] = value;
                    }
                    int n = track.write(stereo, 0, stereo.length);
                    if (n < 0) { log("AudioTrack write error=" + n); break; }
                    written += n;
                    if (block == 15) {
                        AudioDeviceInfo routed = track.getRoutedDevice();
                        log("Actual routed output type=" + (routed == null ? "unknown" : routed.getType())
                            + " id=" + (routed == null ? "unknown" : routed.getId()));
                    }
                }
                log("TELEPHONY TX test wrote " + written + " PCM samples. "
                    + "Only remote participant confirmation proves that sound arrived.");
            } catch (Exception e) {
                log("TELEPHONY TX test FAILED: " + e);
            } finally {
                if (track != null) { try { track.pause(); } catch (Exception ignored) {} track.release(); }
                player = null;
                running.set(false);
            }
        }, "telephony-route-test").start();
    }
    // Network connectivity check only: no microphone or call data is transferred.
    private void connectToMac() {
        new Thread(() -> {
            final String host = "192.168.1.103";
            final int port = 8766;
            try {
                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                Certificate ca;
                try (InputStream in = getResources().openRawResource(R.raw.simbridge_ca_der)) {
                    ca = cf.generateCertificate(in);
                }
                KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
                ks.load(null, null);
                ks.setCertificateEntry("simbridge-local-ca", ca);
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                tmf.init(ks);
                SSLContext tls = SSLContext.getInstance("TLS");
                tls.init(null, tmf.getTrustManagers(), new SecureRandom());
                try (SSLSocket sock = (SSLSocket) tls.getSocketFactory().createSocket(host, port)) {
                    sock.setSoTimeout(8000);
                    SSLParameters params = sock.getSSLParameters();
                    params.setEndpointIdentificationAlgorithm("HTTPS");
                    sock.setSSLParameters(params);
                    sock.startHandshake(); // CA chain AND IP hostname are verified
                    String wsKey;
                    byte[] rand = new byte[16];
                    new SecureRandom().nextBytes(rand);
                    wsKey = Base64.getEncoder().encodeToString(rand);
                    OutputStream out = sock.getOutputStream();
                    String req = "GET / HTTP/1.1\r\n" +
                            "Host: " + host + ":" + port + "\r\n" +
                            "Upgrade: websocket\r\n" +
                            "Connection: Upgrade\r\n" +
                            "Sec-WebSocket-Key: " + wsKey + "\r\n" +
                            "Sec-WebSocket-Version: 13\r\n\r\n";
                    out.write(req.getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    InputStream in = sock.getInputStream();
                    ByteArrayOutputStream header = new ByteArrayOutputStream();
                    int state = 0;
                    while (header.size() < 8192 && state != 4) {
                        int b = in.read();
                        if (b == -1) throw new IOException("WebSocket handshake closed");
                        header.write(b);
                        if ((state == 0 || state == 2) && b == '\r') state++;
                        else if ((state == 1 || state == 3) && b == '\n') state++;
                        else state = (b == '\r') ? 1 : 0;
                    }
                    if (state != 4) throw new IOException("Oversized WebSocket headers");
                    String headers = header.toString("US-ASCII");
                    if (!headers.startsWith("HTTP/1.1 101 "))
                        throw new IOException("WebSocket upgrade rejected: " + headers.split("\r\n")[0]);
                    String accept = Base64.getEncoder().encodeToString(
                        MessageDigest.getInstance("SHA-1").digest(
                            (wsKey + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
                            .getBytes(StandardCharsets.US_ASCII)));
                    boolean validAccept = false;
                    for (String line : headers.split("\r\n")) {
                        if (line.regionMatches(true, 0, "Sec-WebSocket-Accept:", 0, 21)
                                && line.substring(21).trim().equals(accept)) validAccept = true;
                    }
                    if (!validAccept) throw new IOException("WebSocket accept key mismatch");
                    log("WSS TLS and WebSocket handshake verified!");
                    int first = in.read(), second = in.read();
                    if (first == -1 || second == -1) throw new IOException("No server welcome message");
                    int opcode = first & 0x0f;
                    boolean masked = (second & 0x80) != 0;
                    long length = second & 127;
                    if (length == 126) length = ((long) readByte(in) << 8) | readByte(in);
                    else if (length == 127) throw new IOException("Welcome frame too large");
                    if (length > 4096) throw new IOException("Welcome frame too large");
                    byte[] mask = new byte[4];
                    if (masked) readFully(in, mask);
                    byte[] bytes = new byte[(int) length];
                    readFully(in, bytes);
                    if (masked) for (int i = 0; i < bytes.length; i++) bytes[i] ^= mask[i % 4];
                    if (opcode != 1) throw new IOException("Unexpected WebSocket opcode=" + opcode);
                    log("Mac replied: " + new String(bytes, StandardCharsets.UTF_8));
                    log("Network test PASS. No call audio was sent.");
                }
            } catch (Exception e) {
                log("WSS failed: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }, "wss-network-test").start();
    }

    private static int readByte(InputStream in) throws IOException {
        int x = in.read();
        if (x < 0) throw new IOException("Unexpected end of WebSocket frame");
        return x;
    }
    private static void readFully(InputStream in, byte[] out) throws IOException {
        int offset = 0;
        while (offset < out.length) {
            int n = in.read(out, offset, out.length - offset);
            if (n < 0) throw new IOException("Unexpected end of WebSocket payload");
            offset += n;
        }
    }

    // Local-network prototype: two channels of mono 16-kHz PCM16, no codec yet.
    // START only for an authorized test call; without a call playback goes to speaker.
    private void startLiveBridge() {
        if (!consented()) return;
        if (!bridgeOn.compareAndSet(false, true)) { log("Bridge already running"); return; }
        new Thread(() -> {
            SSLSocket sock = null;
            AudioTrack track = null;
            try {
                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                Certificate ca;
                try (InputStream f = getResources().openRawResource(R.raw.simbridge_ca_der)) {
                    ca = cf.generateCertificate(f);
                }
                KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(null, null);
                ks.setCertificateEntry("simbridge-ca", ca);
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                tmf.init(ks);
                SSLContext context = SSLContext.getInstance("TLS");
                context.init(null, tmf.getTrustManagers(), new SecureRandom());
                sock = (SSLSocket) context.getSocketFactory().createSocket("192.168.1.103", 8766);
                bridgeSocket = sock;
                SSLParameters params = sock.getSSLParameters();
                params.setEndpointIdentificationAlgorithm("HTTPS"); sock.setSSLParameters(params);
                sock.startHandshake();
                sock.setSoTimeout(12000);
                InputStream input = sock.getInputStream(); OutputStream output = sock.getOutputStream();
                byte[] nonce = new byte[16]; new SecureRandom().nextBytes(nonce);
                String key = Base64.getEncoder().encodeToString(nonce);
                String req = "GET / HTTP/1.1\r\nHost: 192.168.1.103:8766\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + key + "\r\nSec-WebSocket-Version: 13\r\n\r\n";
                output.write(req.getBytes(StandardCharsets.US_ASCII)); output.flush();
                ByteArrayOutputStream head = new ByteArrayOutputStream();
                int state = 0;
                while (state != 4 && head.size() < 8192) {
                    int b = readByte(input); head.write(b);
                    if ((state == 0 || state == 2) && b == 13) state++;
                    else if ((state == 1 || state == 3) && b == 10) state++;
                    else state = b == 13 ? 1 : 0;
                }
                String headers = head.toString("US-ASCII");
                if (!headers.startsWith("HTTP/1.1 101 ")) throw new IOException("WebSocket upgrade failed");
                String expected = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
                if (!headers.toLowerCase(Locale.US).contains("sec-websocket-accept: " + expected.toLowerCase(Locale.US))) throw new IOException("WebSocket accept mismatch");
                wsSend(output, 1, "redmi".getBytes(StandardCharsets.UTF_8));
                AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
                boolean inCall = audio.getMode() == AudioManager.MODE_IN_CALL;
                int rate = inCall ? 48000 : 16000;
                int chan = inCall ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
                int min = AudioTrack.getMinBufferSize(rate, chan, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) throw new IOException("Invalid AudioTrack buffer");
                track = new AudioTrack.Builder()
                  .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                  .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(chan).build())
                  .setBufferSizeInBytes(Math.max(min * 3, 32768)).setTransferMode(AudioTrack.MODE_STREAM).build();
                if (track.getState() != AudioTrack.STATE_INITIALIZED) throw new IOException("AudioTrack initialization failed");
                if (inCall) {
                    AudioDeviceInfo telephony = null;
                    for (AudioDeviceInfo d : audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS))
                        if (d.getType() == AudioDeviceInfo.TYPE_TELEPHONY && d.isSink()) telephony = d;
                    if (telephony == null || !track.setPreferredDevice(telephony)) throw new IOException("Telephony TX not available");
                }
                track.play(); bridgeTrack = track;
                log("LIVE BRIDGE connected, output=" + (inCall ? "TELEPHONY TX" : "local speaker"));
                final OutputStream sender = output;
                final boolean captureCall = inCall;
                Thread capture = new Thread(() -> sendCapture(sender, captureCall), "simbridge-downlink");
                capture.start();
                sock.setSoTimeout(0);
                while (bridgeOn.get()) {
                    int first = readByte(input), second = readByte(input);
                    int opcode = first & 15;
                    if ((first & 128) == 0) throw new IOException("Fragmented WS frames unsupported");
                    long length = second & 127;
                    if (length == 126) length = ((long)readByte(input)<<8) | readByte(input);
                    else if (length == 127) throw new IOException("WS frame too big");
                    if (length > 131072) throw new IOException("WS payload too large");
                    byte[] mask = new byte[4]; boolean masked = (second & 128) != 0;
                    if (masked) readFully(input, mask);
                    byte[] payload = new byte[(int)length]; readFully(input, payload);
                    if (masked) for (int i=0; i<payload.length; i++) payload[i] ^= mask[i%4];
                    if (opcode == 8) break;
                    if (opcode == 9) { wsSend(output, 10, payload); continue; }
                    if (opcode == 2 && payload.length >= 2) {
                        // 16-kHz mono little-endian PCM16; 48-kHz stereo for telephony sink.
                        short[] pcm = new short[payload.length/2 * (inCall ? 6 : 1)];
                        int index=0;
                        for (int i=0; i+1<payload.length; i+=2) {
                            short v=(short)((payload[i]&255)|((payload[i+1]&255)<<8));
                            if (inCall) { for (int j=0;j<3;j++) { pcm[index++]=v; pcm[index++]=v; } }
                            else pcm[index++]=v;
                        }
                        int offset=0;
                        while (bridgeOn.get() && offset<index) {
                            int wrote=track.write(pcm, offset, index-offset);
                            if (wrote<=0) throw new IOException("AudioTrack write="+wrote);
                            offset+=wrote;
                        }
                    }
                }
            } catch (Exception e) { if (bridgeOn.get()) log("LIVE BRIDGE error: " + e.getMessage()); }
            finally {
                bridgeOn.set(false);
                if (sock!=null) try { sock.close(); } catch(Exception ignored) {}
                if (track!=null) { try { track.stop(); } catch(Exception ignored){} track.release(); }
                bridgeTrack=null; bridgeSocket=null; log("LIVE BRIDGE stopped");
            }
        }, "simbridge-live-wss").start();
    }
    private void sendCapture(OutputStream out, boolean inCall) {
        AudioRecord r=null;
        try {
            int min=AudioRecord.getMinBufferSize(hz, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min<=0) throw new IOException("Bad record buffer");
            r=new AudioRecord(inCall ? MediaRecorder.AudioSource.VOICE_DOWNLINK : MediaRecorder.AudioSource.MIC,
                 hz, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min*3, 8192));
            bridgeRecorder=r;
            if (r.getState()!=AudioRecord.STATE_INITIALIZED) throw new IOException("AudioRecord init failed");
            r.startRecording();
            byte[] data=new byte[640]; // 20 ms at 16 kHz mono PCM16
            while (bridgeOn.get()) {
                int n=r.read(data,0,data.length,AudioRecord.READ_BLOCKING);
                if (n>0) wsSend(out,2,java.util.Arrays.copyOf(data,n));
                else if (n<0) throw new IOException("AudioRecord read="+n);
            }
        } catch(Exception e) { if(bridgeOn.get()) log("Capture stopped: "+e.getMessage()); }
        finally { if(r!=null) { try{r.stop();}catch(Exception ignored){} r.release(); } bridgeRecorder=null; }
    }
    private void wsSend(OutputStream out, int opcode, byte[] data) throws IOException {
        synchronized(sendLock) {
            int length=data.length;
            out.write(0x80 | opcode);
            if(length<126) out.write(0x80|length);
            else if(length<=65535) { out.write(0x80|126); out.write((length>>8)&255); out.write(length&255); }
            else throw new IOException("WS message too long");
            byte[] mask=new byte[4]; new SecureRandom().nextBytes(mask);
            out.write(mask);
            byte[] result=new byte[length];
            for(int i=0;i<length;i++) result[i]=(byte)(data[i]^mask[i%4]);
            out.write(result); out.flush();
        }
    }
    private void stopLiveBridge() {
        bridgeOn.set(false);
        SSLSocket s=bridgeSocket; if(s!=null) try{s.close();}catch(Exception ignored){}
        AudioRecord r=bridgeRecorder; if(r!=null) try{r.stop();}catch(Exception ignored){}
        log("LIVE BRIDGE stop requested");
    }
    private void stop() {
        running.set(false);
        log("Stop requested.");
        // Worker releases audio objects; avoid concurrent release here.
    }
    @Override protected void onDestroy() { running.set(false); stopLiveBridge(); super.onDestroy(); }
}

