package com.simbridge.audiolab;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.util.Log;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Audio runs only during an answered cellular call and an authenticated remote session. */
public final class GatewayAudioEngine {
    public interface Output { void sendAudio(byte[] data) throws IOException; }
    private static final String TAG = "SIMBridgeAudio";
    private static final int RATE = 16000;
    private static final int OUTPUT_RATE = 48000;
    private final Context context;
    private final PcmJitterBuffer incoming = new PcmJitterBuffer(15);
    private final ArrayBlockingQueue<byte[]> outgoing = new ArrayBlockingQueue<>(15);
    private volatile boolean running;
    private volatile long generation;
    private AudioRecord recorder;
    private AudioTrack track;
    private Thread captureThread, senderThread, playbackThread;

    public GatewayAudioEngine(Context context) { this.context = context.getApplicationContext(); }
    public synchronized boolean isRunning() { return running; }

    public synchronized void start(Output sink) throws IOException {
        if (running) return;
        AudioManager manager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int inMin = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int outMin = AudioTrack.getMinBufferSize(OUTPUT_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (inMin <= 0 || outMin <= 0) throw new IOException("Unsupported PCM settings: " + inMin + " / " + outMin);
        AudioDeviceInfo telephony = null;
        for (AudioDeviceInfo device : manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            if (device.getType() == AudioDeviceInfo.TYPE_TELEPHONY && device.isSink()) { telephony = device; break; }
        }
        if (telephony == null) throw new IOException("TELEPHONY TX not available");
        AudioRecord newRecorder = null;
        AudioTrack newTrack = null;
        try {
            newRecorder = new AudioRecord(MediaRecorder.AudioSource.VOICE_DOWNLINK, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(inMin * 2, 8192));
            if (newRecorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IOException("VOICE_DOWNLINK init failed");
            newTrack = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(OUTPUT_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(Math.max(outMin * 2, 16384))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
            if (newTrack.getState() != AudioTrack.STATE_INITIALIZED) throw new IOException("AudioTrack init failed");
            if (!newTrack.setPreferredDevice(telephony)) throw new IOException("TELEPHONY TX route refused");
            newTrack.play();
            newRecorder.startRecording();
            if (newRecorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IOException("VOICE_DOWNLINK failed to start");
            recorder = newRecorder;
            track = newTrack;
            incoming.clear(); outgoing.clear();
            running = true;
        } catch (Exception err) {
            if (newRecorder != null) { try { newRecorder.stop(); } catch (Exception ignored) {} newRecorder.release(); }
            if (newTrack != null) { try { newTrack.stop(); } catch (Exception ignored) {} newTrack.release(); }
            if (err instanceof IOException) throw (IOException) err;
            throw new IOException("Audio initialization failed", err);
        }
        final long gen = ++generation;
        final AudioRecord ownRecorder = recorder;
        final AudioTrack ownTrack = track;
        captureThread = new Thread(() -> capture(gen, ownRecorder), "gateway-voice-downlink");
        senderThread = new Thread(() -> send(gen, sink), "gateway-ws-audio-send");
        playbackThread = new Thread(() -> playback(gen, ownTrack), "gateway-telephony-tx");
        captureThread.start(); senderThread.start(); playbackThread.start();
        Log.i(TAG, "Live call audio started (16k mono PCM16, TELEPHONY TX 48k stereo)");
        LocalSilence.apply(context);
    }

    public void offer(byte[] pcm) { if (running) incoming.offer(pcm); }

    private void capture(long gen, AudioRecord source) {
        byte[] buf = new byte[PcmJitterBuffer.FRAME_BYTES];
        try {
            while (running && gen == generation) {
                int filled = 0;
                while (running && gen == generation && filled < buf.length) {
                    int got = source.read(buf, filled, buf.length - filled, AudioRecord.READ_BLOCKING);
                    if (got < 0) throw new IOException("AudioRecord read error " + got);
                    filled += got;
                }
                if (!running || gen != generation) break;
                byte[] frame = Arrays.copyOf(buf, buf.length);
                if (!outgoing.offer(frame)) { outgoing.poll(); outgoing.offer(frame); }
            }
        } catch (Exception ex) { if (running && gen == generation) { Log.e(TAG,"Capture failed",ex); stop(); } }
    }

    private void send(long gen, Output sink) {
        try {
            while (running && gen == generation) {
                byte[] frame = outgoing.poll(250, TimeUnit.MILLISECONDS);
                if (frame != null) sink.sendAudio(frame);
            }
        } catch (Exception ex) { if (running && gen == generation) { Log.e(TAG,"Network send failed",ex); stop(); } }
    }

    private void playback(long gen, AudioTrack output) {
        PcmResampler resampler = new PcmResampler();
        long tick = System.nanoTime();
        try {
            while (running && gen == generation) {
                short[] samples = resampler.convert(incoming.poll());
                int written = 0;
                while (running && gen == generation && written < samples.length) {
                    int n = output.write(samples, written, samples.length - written, AudioTrack.WRITE_BLOCKING);
                    if (n <= 0) throw new IOException("AudioTrack write error " + n);
                    written += n;
                }
                tick += 20_000_000L;
                long wait = tick - System.nanoTime();
                if (wait > 0) TimeUnit.NANOSECONDS.sleep(wait);
                else if (wait < -100_000_000L) tick = System.nanoTime();
            }
        } catch (Exception ex) { if (running && gen == generation) { Log.e(TAG,"Telephony playback failed",ex); stop(); } }
    }

    public synchronized void stop() {
        if (!running && recorder == null && track == null) return;
        running = false; generation++;
        incoming.clear(); outgoing.clear();
        AudioRecord r = recorder; recorder = null;
        AudioTrack p = track; track = null;
        if (r != null) { try { r.stop(); } catch (Exception ignored) {} r.release(); }
        if (p != null) { try { p.pause(); p.flush(); p.stop(); } catch (Exception ignored) {} p.release(); }
        LocalSilence.restore(context);
        Log.i(TAG, "Live call audio stopped");
    }

    public String metrics() {
        return "inputQueue=" + incoming.queued() + " inputDrops=" + incoming.dropped()
                + " inputUnderruns=" + incoming.underruns() + " outputQueue=" + outgoing.size();
    }
}
