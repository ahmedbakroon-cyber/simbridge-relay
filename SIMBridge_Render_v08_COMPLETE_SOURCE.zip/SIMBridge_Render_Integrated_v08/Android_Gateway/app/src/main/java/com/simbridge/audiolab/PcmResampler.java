package com.simbridge.audiolab;

/** Linear interpolation 16 kHz mono PCM16 -> 48 kHz stereo for TYPE_TELEPHONY. */
public final class PcmResampler {
    private short lastSample;

    public short[] convert(byte[] pcm) {
        int count = pcm.length / 2;
        short[] out = new short[count * 6];
        int j = 0;
        for (int i = 0; i < count; i++) {
            short value = (short) ((pcm[2*i] & 255) | ((pcm[2*i+1] & 255) << 8));
            int delta = value - lastSample;
            for (int x = 1; x <= 3; x++) {
                short interpolated = (short) (lastSample + delta * x / 3);
                out[j++] = interpolated;
                out[j++] = interpolated;
            }
            lastSample = value;
        }
        return out;
    }
    public void reset() { lastSample = 0; }
}
