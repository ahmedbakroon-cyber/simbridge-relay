package com.simbridge.audiolab;

import java.util.ArrayDeque;
import java.util.Arrays;

/** 20 ms PCM16/16k mono frames. Bounded queue: old frames are dropped, never grow latency unbounded. */
public final class PcmJitterBuffer {
    public static final int FRAME_BYTES = 640;
    private final ArrayDeque<byte[]> packets = new ArrayDeque<>();
    private final int capacity;
    private long dropped, underruns;
    private boolean primed;

    public PcmJitterBuffer(int capacity) {
        if (capacity < 3) throw new IllegalArgumentException("capacity must be >= 3");
        this.capacity = capacity;
    }

    public synchronized void offer(byte[] packet) {
        if (packet == null || packet.length == 0 || packet.length % 2 != 0) return;
        // A network frame can contain multiple 20 ms packets or a short trailing packet.
        for (int i = 0; i < packet.length; i += FRAME_BYTES) {
            byte[] frame = new byte[FRAME_BYTES];
            System.arraycopy(packet, i, frame, 0, Math.min(FRAME_BYTES, packet.length - i));
            if (packets.size() >= capacity) { packets.removeFirst(); dropped++; }
            packets.addLast(frame);
        }
    }

    /** Returns silence when underflowing; waits for 3 frames to accumulate after a hard underflow. */
    public synchronized byte[] poll() {
        if (!primed) {
            if (packets.size() < 3) return new byte[FRAME_BYTES];
            primed = true;
        }
        if (packets.isEmpty()) { primed = false; underruns++; return new byte[FRAME_BYTES]; }
        return packets.removeFirst();
    }

    public synchronized void clear() { packets.clear(); primed = false; }
    public synchronized int queued() { return packets.size(); }
    public synchronized long dropped() { return dropped; }
    public synchronized long underruns() { return underruns; }
}
