package com.simbridge.audiolab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

/** Visible foreground service; leaves the user's separate Telegram application unchanged. */
public final class GatewayService extends Service {
    public static final String START="com.simbridge.audiolab.GATEWAY_START";
    public static final String STOP="com.simbridge.audiolab.GATEWAY_STOP";
    private static final String CHANNEL="simbridge_gateway_service";
    private volatile GatewayServer server;
    private volatile ReverseTunnel tunnel;
    private volatile RenderTunnel renderTunnel;
    private static volatile String status="Not started";
    private volatile boolean starting;
    private volatile boolean destroyed;
    private static volatile GatewayServer active;
    public static String status(){return status + (active==null ? "" : "\n" + active.status() + "\nRelay=" + (RenderTunnel.state().equals("OFF") ? ReverseTunnel.state() : RenderTunnel.state()));}
    @Override public void onCreate(){super.onCreate();
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(
            CHANNEL,"SIM Bridge Redmi gateway",NotificationManager.IMPORTANCE_LOW));
    }
    private Notification notification(String message){
        Intent launch=new Intent(this,HomeActivity.class);
        PendingIntent action=PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setContentTitle("SIM Bridge Redmi Gateway")
            .setContentText(message).setContentIntent(action)
            .setOngoing(true).build();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&STOP.equals(intent.getAction())){
            status="Stopped by user";
            GatewayServer old=server;server=null;active=null;stopTunnel();if(old!=null)old.stop();
            stopForeground(true);stopSelf();return START_NOT_STICKY;
        }
        startForeground(622,notification("HTTPS + secure remote call bridge"));
        if(server==null && !starting){
            starting=true;status="Starting server...";
            new Thread(()->{
                try{
                    GatewayServer newServer=new GatewayServer(this,GatewayConfig.token(this));
                    newServer.start(GatewayConfig.password(this));
                    if(destroyed){newServer.stop();return;}
                    server=newServer;active=newServer;status="Listening securely on port 8443";
                    startTunnelIfConfigured(newServer);
                }catch(Exception e){
                    status="Gateway start failed: "+e.getMessage();
                    Log.e("SIMBridgeGateway",status,e);stopSelf();
                }finally{starting=false;}
            },"gateway-server-start").start();
        }
        return START_STICKY;
    }
    private void startTunnelIfConfigured(GatewayServer srv){
        String address=GatewayConfig.relayAddress(this),secret=GatewayConfig.relaySecret(this);
        if(address.isEmpty()||secret.isEmpty())return;
        if (address.startsWith("https://") || address.startsWith("wss://") || address.endsWith(".onrender.com")) {
            RenderTunnel t = new RenderTunnel(address, secret, GatewayConfig.token(this), srv);
            renderTunnel=t;t.start();return;
        }
        String host=address;int port=9000;
        int colon=address.lastIndexOf(':');
        if(colon>0){host=address.substring(0,colon);try{port=Integer.parseInt(address.substring(colon+1).trim());}catch(NumberFormatException ignored){}}
        ReverseTunnel t=new ReverseTunnel(host.trim(),port,secret,srv::acceptTunneled);
        tunnel=t;t.start();
    }
    private void stopTunnel(){ReverseTunnel t=tunnel;tunnel=null;if(t!=null)t.stop();
        RenderTunnel r=renderTunnel;renderTunnel=null;if(r!=null)r.stop();}
    @Override public void onDestroy(){destroyed=true;GatewayServer old=server;server=null;active=null;stopTunnel();
        if(old!=null)old.stop();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
