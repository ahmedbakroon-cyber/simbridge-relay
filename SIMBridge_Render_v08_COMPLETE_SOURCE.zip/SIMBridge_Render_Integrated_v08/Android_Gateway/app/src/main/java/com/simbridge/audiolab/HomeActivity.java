package com.simbridge.audiolab;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PersistableBundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** New simple home screen. The old test screen (MainActivity) stays available under "Advanced tools". */
public class HomeActivity extends Activity {
    private static final int BG = Color.parseColor("#0F172A"), CARD = Color.parseColor("#1E293B"),
        FIELD = Color.parseColor("#0B1220"), TEXT = Color.parseColor("#E2E8F0"),
        MUTED = Color.parseColor("#94A3B8"), TEAL = Color.parseColor("#14B8A6"),
        RED = Color.parseColor("#F43F5E"), GREEN = Color.parseColor("#22C55E"),
        AMBER = Color.parseColor("#F59E0B"), GRAY = Color.parseColor("#64748B"),
        SLATE = Color.parseColor("#334155");
    private static final int REQ_PERMS = 56, REQ_CERT = 155, PORT = 8443;
    private static final String PREFS = "home_v06";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable poll = new Runnable() {
        @Override public void run() { refresh(); ui.postDelayed(this, 1000); }
    };

    private View dot;
    private TextView statusTitle, statusSub, rowCert, rowPerm, rowBattery, rowPhone, rowRelay, rowCall, urlText, tokenText;
    private Button mainBtn, permBtn, batteryBtn, tokenShowBtn, silenceBtn;
    private LinearLayout setupCard, certBlock;
    private EditText pwdField, relayAddrField, relaySecretField;
    private boolean certOk, tokenShown, forceCert;
    private String lastUrls = "";

    // ---------- small UI helpers ----------
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d;
    }
    private LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top); return p;
    }
    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackground(rounded(CARD, 18));
        parent.addView(c, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 14));
        return c;
    }
    private TextView text(LinearLayout parent, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.START);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        parent.addView(t, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 6));
        return t;
    }
    private Button button(LinearLayout parent, String label, int bg, View.OnClickListener h) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setBackground(rounded(bg, 14)); b.setOnClickListener(h);
        parent.addView(b, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52), 10));
        return b;
    }
    private TextView row(LinearLayout parent, String label) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        TextView l = new TextView(this);
        l.setText(label); l.setTextColor(MUTED); l.setTextSize(15);
        TextView v = new TextView(this);
        v.setTextColor(TEXT); v.setTextSize(15); v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.END);
        r.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
        parent.addView(r, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        return v;
    }

    // ---------- lifecycle ----------
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(28));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        text(root, "SIM Bridge", 30, TEXT, true);
        text(root, "رد على مكالمات شريحة الـRedmi من الـiPhone", 15, MUTED, false);

        // Status card
        LinearLayout status = card(root);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        dot = new View(this);
        head.addView(dot, new LinearLayout.LayoutParams(dp(14), dp(14)));
        statusTitle = new TextView(this);
        statusTitle.setTextSize(22); statusTitle.setTextColor(TEXT); statusTitle.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.setMarginStart(dp(10));
        head.addView(statusTitle, tp);
        status.addView(head);
        statusSub = text(status, "", 14, MUTED, false);
        mainBtn = button(status, "تشغيل البوابة", TEAL, v -> onMainButton());
        mainBtn.setTextSize(18);

        // Live info
        LinearLayout info = card(root);
        rowPhone = row(info, "iPhone");
        rowRelay = row(info, "السيرفر الوسيط");
        rowCall = row(info, "المكالمة");
        rowCert = row(info, "الشهادة");
        rowPerm = row(info, "الصلاحيات");
        rowBattery = row(info, "توفير البطارية");

        // Setup (only incomplete items are shown)
        setupCard = card(root);
        text(setupCard, "الإعداد", 18, TEXT, true);
        permBtn = button(setupCard, "منح الصلاحيات (المايك والهاتف)", SLATE, v -> requestPerms());
        certBlock = new LinearLayout(this);
        certBlock.setOrientation(LinearLayout.VERTICAL);
        text(certBlock, "شهادة HTTPS: اكتب كلمة سر ملف gateway.p12 ثم اختر الملف", 14, MUTED, false);
        pwdField = new EditText(this);
        pwdField.setHint("كلمة سر الشهادة");
        pwdField.setHintTextColor(GRAY); pwdField.setTextColor(TEXT);
        pwdField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pwdField.setBackground(rounded(FIELD, 12));
        pwdField.setPadding(dp(14), 0, dp(14), 0);
        certBlock.addView(pwdField, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 10));
        button(certBlock, "اختيار ملف الشهادة (.p12)", SLATE, v -> pickCert());
        setupCard.addView(certBlock);
        batteryBtn = button(setupCard, "استثناء التطبيق من توفير البطارية", SLATE, v -> openBattery());

        // Address
        LinearLayout addr = card(root);
        text(addr, "عنوان الصفحة على الـiPhone (Safari)", 14, MUTED, false);
        urlText = text(addr, "", 17, TEXT, true);
        urlText.setTextIsSelectable(true);
        button(addr, "نسخ العنوان", SLATE, v -> copyUrl());

        // Pairing token
        LinearLayout tok = card(root);
        text(tok, "رمز الربط (للـiPhone فقط)", 14, MUTED, false);
        tokenText = text(tok, "", 15, TEXT, false);
        tokenText.setTypeface(Typeface.MONOSPACE);
        LinearLayout tr = new LinearLayout(this);
        tr.setOrientation(LinearLayout.HORIZONTAL);
        tokenShowBtn = new Button(this);
        styleSmall(tokenShowBtn, "إظهار", v -> { tokenShown = !tokenShown; refresh(); });
        Button copyTok = new Button(this);
        styleSmall(copyTok, "نسخ الرمز", v -> copyToken());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(46), 1f);
        half.setMarginEnd(dp(8));
        tr.addView(copyTok, half);
        tr.addView(tokenShowBtn, new LinearLayout.LayoutParams(0, dp(46), 1f));
        tok.addView(tr, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 10));

        // Relay (Google Cloud)
        LinearLayout rel = card(root);
        text(rel, "السيرفر الوسيط (Google Cloud)", 14, MUTED, false);
        text(rel, "اتركه فارغاً لاستخدام الهوتسبوت المحلي فقط", 12, GRAY, false);
        relayAddrField = new EditText(this);
        relayAddrField.setHint("https://YOUR-NAME.onrender.com");
        relayAddrField.setHintTextColor(GRAY); relayAddrField.setTextColor(TEXT);
        relayAddrField.setSingleLine(true);
        relayAddrField.setBackground(rounded(FIELD, 12));
        relayAddrField.setPadding(dp(14), 0, dp(14), 0);
        relayAddrField.setText(GatewayConfig.relayAddress(this));
        rel.addView(relayAddrField, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 10));
        relaySecretField = new EditText(this);
        relaySecretField.setHint(GatewayConfig.relaySecret(this).isEmpty() ? "السر المشترك مع السيرفر" : "السر محفوظ (اكتب سراً جديداً لتغييره)");
        relaySecretField.setHintTextColor(GRAY); relaySecretField.setTextColor(TEXT);
        relaySecretField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        relaySecretField.setBackground(rounded(FIELD, 12));
        relaySecretField.setPadding(dp(14), 0, dp(14), 0);
        rel.addView(relaySecretField, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(50), 10));
        button(rel, "حفظ إعدادات السيرفر الوسيط", SLATE, v -> saveRelay());
        button(rel, "إلغاء السيرفر الوسيط", SLATE, v -> {
            GatewayConfig.clearRelay(this);
            relayAddrField.setText(""); relaySecretField.setText("");
            toast("أُلغي. أعد تشغيل البوابة ليسري التغيير.");
            refresh();
        });

        // Options
        LinearLayout opt = card(root);
        silenceBtn = button(opt, "", SLATE, v -> { LocalSilence.setEnabled(this, !LocalSilence.enabled(this)); refresh(); });
        text(opt, "عند تحويل الصوت للـiPhone يُكتم مايك الـRedmi ويُخفض صوت المكالمة فيه لأدنى مستوى، ثم يعود كما كان بعد المكالمة. إذا لم يسمعك المتصل فعطّل هذا الخيار.", 12, MUTED, false);
        button(opt, "استبدال الشهادة", SLATE, v -> { forceCert = !forceCert; refresh(); });
        button(opt, "أدوات الاختبار المتقدمة", SLATE,
            v -> startActivity(new Intent(this, MainActivity.class)));
        TextView ver = text(root, "SIM Bridge 0.7", 12, GRAY, false);
        ver.setGravity(Gravity.CENTER);

        setContentView(scroll);
    }
    private void styleSmall(Button b, String label, View.OnClickListener h) {
        b.setText(label); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(Color.WHITE);
        b.setBackground(rounded(SLATE, 12)); b.setOnClickListener(h);
    }
    @Override protected void onResume() {
        super.onResume();
        if (!GatewayService.status().contains("call=ACTIVE")) LocalSilence.restore(this); // never leave the phone muted
        recomputeSetup();
        ui.post(poll);
    }
    @Override protected void onPause() {
        ui.removeCallbacks(poll);
        super.onPause();
    }

    // ---------- setup state ----------
    private static final String[] PERMS = {Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS};
    private boolean hasPerms() {
        for (String p : PERMS) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }
    private void requestPerms() { requestPermissions(PERMS, REQ_PERMS); }
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        refresh();
    }
    private boolean batteryOk() {
        PowerManager pm = getSystemService(PowerManager.class);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }
    private void openBattery() {
        try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
        catch (Exception e) { toast("افتح إعدادات البطارية واستثنِ التطبيق يدوياً"); }
    }
    /** Keystore access is slow, so this is not done on every poll. */
    private void recomputeSetup() {
        boolean file = new File(getFilesDir(), "gateway.p12").exists();
        boolean pw;
        try { pw = !GatewayConfig.password(this).isEmpty(); } catch (Exception e) { pw = false; }
        certOk = file && pw;
        refresh();
    }

    // ---------- actions ----------
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private boolean consentGiven() { return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("consent", false); }
    private void onMainButton() {
        String st = GatewayService.status();
        boolean on = st.contains("Server=RUNNING") || st.contains("Starting server");
        if (on) {
            startService(new Intent(this, GatewayService.class).setAction(GatewayService.STOP));
            toast("تم طلب إيقاف البوابة");
            ui.postDelayed(this::refresh, 600);
            return;
        }
        if (!hasPerms()) { toast("امنح الصلاحيات أولاً"); requestPerms(); return; }
        if (!certOk) { toast("استورد شهادة HTTPS أولاً"); forceCert = true; refresh(); return; }
        if (!consentGiven()) {
            new AlertDialog.Builder(this)
                .setTitle("تأكيد")
                .setMessage("أؤكد أن المكالمات تخصني، أو أن جميع الأطراف موافقون على نقل صوت المكالمة إلى الـiPhone.")
                .setPositiveButton("أوافق", (d, w) -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("consent", true).apply();
                    onMainButton();
                })
                .setNegativeButton("إلغاء", null).show();
            return;
        }
        startForegroundService(new Intent(this, GatewayService.class).setAction(GatewayService.START));
        ui.postDelayed(this::refresh, 600);
    }
    private void pickCert() {
        String pw = pwdField.getText().toString();
        if (pw.isEmpty()) { toast("اكتب كلمة سر الشهادة أولاً"); return; }
        try { GatewayConfig.storePassword(this, pw); }
        catch (Exception e) { toast("تعذر حفظ كلمة السر: " + e.getMessage()); return; }
        pwdField.setText("");
        Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        picker.setType("*/*");
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(picker, REQ_CERT);
    }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code != REQ_CERT || result != RESULT_OK || data == null || data.getData() == null) return;
        File tmp = new File(getFilesDir(), "gateway.p12.tmp");
        File dest = new File(getFilesDir(), "gateway.p12");
        try (InputStream in = getContentResolver().openInputStream(data.getData());
             FileOutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new IOException("تعذر قراءة الملف");
            byte[] buf = new byte[4096]; int n; long total = 0;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > 128_000) throw new IOException("الملف أكبر من 128KB");
                out.write(buf, 0, n);
            }
            if (total < 100) throw new IOException("الملف صغير جداً");
        } catch (Exception e) {
            tmp.delete();
            toast("فشل استيراد الشهادة: " + e.getMessage());
            return;
        }
        if (dest.exists()) dest.delete();
        if (!tmp.renameTo(dest)) { tmp.delete(); toast("تعذر حفظ الشهادة"); return; }
        forceCert = false;
        toast("تم استيراد الشهادة. أعد تشغيل البوابة إن كانت تعمل.");
        recomputeSetup();
    }
    private void copy(String label, String value, boolean sensitive) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText(label, value);
        if (sensitive && Build.VERSION.SDK_INT >= 33) {
            PersistableBundle extras = new PersistableBundle();
            extras.putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true);
            clip.getDescription().setExtras(extras);
        }
        cm.setPrimaryClip(clip);
    }
    private void saveRelay() {
        String addr = relayAddrField.getText().toString().trim();
        String secret = relaySecretField.getText().toString();
        if (addr.isEmpty()) { toast("اكتب عنوان السيرفر الوسيط"); return; }
        if (!(addr.matches("[A-Za-z0-9.-]+(:[0-9]{1,5})?") ||
              addr.matches("https://[A-Za-z0-9.-]+/?") || addr.matches("wss://[A-Za-z0-9.-]+/?"))) {
            toast("مثال: https://your-name.onrender.com"); return;
        }
        boolean hadSecret = !GatewayConfig.relaySecret(this).isEmpty();
        if (secret.isEmpty() && !hadSecret) { toast("اكتب السر المشترك"); return; }
        if (!secret.isEmpty() && secret.length() < 24) { toast("السر قصير: يجب 24 حرفاً على الأقل"); return; }
        try { GatewayConfig.storeRelay(this, addr, secret); }
        catch (Exception e) { toast("تعذر الحفظ: " + e.getMessage()); return; }
        relaySecretField.setText("");
        toast("تم الحفظ. أعد تشغيل البوابة ليسري التغيير.");
        refresh();
    }
    /** Public address of the relay as the iPhone sees it (https://host:8443/), or null if not configured. */
    private String relayUrl() {
        String a = GatewayConfig.relayAddress(this);
        if (a.isEmpty() || GatewayConfig.relaySecret(this).isEmpty()) return null;
        if (a.startsWith("https://")) return a.endsWith("/") ? a : a + "/";
        if (a.startsWith("wss://")) return "https://" + a.substring(6) + (a.endsWith("/") ? "" : "/");
        if (a.endsWith(".onrender.com")) return "https://" + a + "/";
        int i = a.lastIndexOf(':');
        return "https://" + (i > 0 ? a.substring(0, i) : a) + ":" + PORT + "/";
    }
    private void copyToken() { copy("SIM Bridge pairing token", GatewayConfig.token(this), true); toast("تم نسخ الرمز. لا تشاركه مع أحد."); }
    private void copyUrl() {
        List<String> ips = localIps();
        String relay = relayUrl();
        if (relay == null && ips.isEmpty()) { toast("لا يوجد اتصال شبكة"); return; }
        copy("SIM Bridge URL", relay != null ? relay : "https://" + ips.get(0) + ":" + PORT + "/", false);
        toast("تم نسخ العنوان");
    }

    // ---------- live status ----------
    private List<String> localIps() {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) out.add(a.getHostAddress());
            }
        } catch (Exception ignored) { }
        return out;
    }
    private String ok(boolean v) { return v ? "✓ جاهز" : "✗ ناقص"; }
    private void refresh() {
        if (statusTitle == null) return;
        String st = GatewayService.status();
        boolean running = st.contains("Server=RUNNING");
        boolean starting = !running && st.contains("Starting server");
        boolean failed = !running && st.contains("Gateway start failed");
        boolean client = st.contains("client=connected");
        String call = "IDLE";
        int i = st.indexOf("call=");
        if (i >= 0) {
            int e = st.indexOf(' ', i);
            call = st.substring(i + 5, e > 0 ? e : st.length()).trim();
        }
        int color = running ? GREEN : starting ? AMBER : failed ? RED : GRAY;
        dot.setBackground(rounded(color, 7));
        statusTitle.setText(running ? "البوابة تعمل" : starting ? "جارٍ التشغيل…" : failed ? "فشل التشغيل" : "البوابة متوقفة");
        if (running) statusSub.setText(client ? "الـiPhone متصل وجاهز لاستقبال المكالمات" : "بانتظار اتصال الـiPhone");
        else if (failed) {
            int k = st.indexOf("Gateway start failed:");
            String err = st.substring(k + 21).trim();
            int nl = err.indexOf('\n');
            statusSub.setText(nl > 0 ? err.substring(0, nl) : err);
        } else statusSub.setText(starting ? "لحظات…" : "اضغط تشغيل لبدء البوابة");
        mainBtn.setText(running || starting ? "إيقاف البوابة" : "تشغيل البوابة");
        mainBtn.setBackground(rounded(running || starting ? RED : TEAL, 14));

        boolean perms = hasPerms(), battery = batteryOk();
        rowPhone.setText(running ? (client ? "● متصل" : "○ غير متصل") : "—");
        String relayState = "—";
        if (relayUrl() == null) relayState = "غير مفعّل";
        else if (running) {
            int r = st.indexOf("Relay=");
            String v = r >= 0 ? st.substring(r + 6).split("\n")[0].trim() : "";
            relayState = ("CONNECTED".equals(v) || "READY".equals(v)) ? "● متصل" : v.startsWith("ERROR") ? "✗ خطأ" : "… جارٍ الاتصال";
        }
        rowRelay.setText(relayState);
        rowCall.setText(!running ? "—" : "RINGING".equals(call) ? "مكالمة واردة" : "ACTIVE".equals(call) ? "مكالمة جارية" : "لا توجد مكالمة");
        rowCert.setText(ok(certOk));
        rowPerm.setText(ok(perms));
        rowBattery.setText(battery ? "✓ مستثنى" : "! غير مستثنى");

        boolean needSetup = !perms || !certOk || !battery || forceCert;
        setupCard.setVisibility(needSetup ? View.VISIBLE : View.GONE);
        permBtn.setVisibility(perms ? View.GONE : View.VISIBLE);
        certBlock.setVisibility(!certOk || forceCert ? View.VISIBLE : View.GONE);
        batteryBtn.setVisibility(battery ? View.GONE : View.VISIBLE);

        List<String> ips = localIps();
        StringBuilder sb = new StringBuilder();
        String relayLink = relayUrl();
        if (relayLink != null) sb.append(relayLink).append('\n');
        for (String ip : ips) sb.append("https://").append(ip).append(':').append(PORT).append("/\n");
        String urls = (ips.isEmpty() && relayLink == null) ? "لا يوجد اتصال شبكة.\nشغّل الهوتسبوت أو اتصل بالواي فاي." : sb.toString().trim();
        if (!urls.equals(lastUrls)) { urlText.setText(urls); lastUrls = urls; }
        tokenText.setText(tokenShown ? GatewayConfig.token(this) : "••••••••••••••••••••••••");
        tokenShowBtn.setText(tokenShown ? "إخفاء" : "إظهار");
        silenceBtn.setText(LocalSilence.enabled(this) ? "كتم الـRedmi أثناء المكالمة: مفعّل" : "كتم الـRedmi أثناء المكالمة: معطّل");
    }
}
