package com.simbridge.audiolab;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;

/** Minimal HTTPS + RFC6455 server, one authenticated iPhone session, no external relay.
 *  Prototype: private Tailscale network only; never expose port 8443 on the public internet.
 */
public final class GatewayServer {
    private static final String TAG = "SIMBridgeGateway";
    public static final int PORT = 8443;
    private static final int MAX_FRAME = 131072;
    private final Context app;
    private final String token;
    private final GatewayAudioEngine engine;
    private final Object sessionLock = new Object();
    private volatile SSLServerSocket listener;
    private volatile boolean running;
    private volatile Session session;
    private volatile String currentState = "IDLE";
    private Thread acceptThread, pollThread;
    private volatile String lastError = "";
    private volatile long nextAudioAttemptMs;

    public GatewayServer(Context ctx, String token) {
        this.app = ctx.getApplicationContext();
        this.token = token;
        this.engine = new GatewayAudioEngine(app);
    }

    private volatile SSLContext tlsCtx;

    /** A connection that arrived through the relay: the iPhone's raw TLS bytes flow over this plain socket. */
    public void acceptTunneled(Socket plain) throws IOException {
        SSLContext ctx = tlsCtx;
        if (!running || ctx == null) { plain.close(); return; }
        plain.setTcpNoDelay(true);
        plain.setSendBufferSize(16 * 1024);
        SSLSocket ssl = (SSLSocket) ctx.getSocketFactory().createSocket(plain, plain.getInetAddress().getHostAddress(), plain.getPort(), true);
        ssl.setUseClientMode(false);
        ssl.setSoTimeout(10000);
        new Thread(() -> handleClient(ssl), "gateway-tunnel-client").start();
    }

    public synchronized void start(String p12Password) throws Exception {
        if (running) return;
        File file = new File(app.getFilesDir(), "gateway.p12");
        if (!file.isFile()) throw new IOException("Import a gateway PKCS12 TLS certificate first");
        KeyStore ks = KeyStore.getInstance("PKCS12");
        char[] pass = p12Password.toCharArray();
        try (InputStream src = new FileInputStream(file)) { ks.load(src, pass); }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, pass);
        Arrays.fill(pass, '\0');
        SSLContext tls = SSLContext.getInstance("TLS");
        tls.init(kmf.getKeyManagers(), null, new SecureRandom());
        tlsCtx = tls;
        SSLServerSocket server = (SSLServerSocket) tls.getServerSocketFactory().createServerSocket();
        server.setReuseAddress(true);
        // Tailscale's VPN address will be reachable; access requires a TLS connection and secret token.
        server.bind(new InetSocketAddress("0.0.0.0", PORT), 16);
        server.setSoTimeout(1000);
        listener = server; running = true;
        acceptThread = new Thread(this::acceptLoop, "gateway-https-accept");
        pollThread = new Thread(this::pollCalls, "gateway-cellular-monitor");
        acceptThread.start(); pollThread.start();
        Log.i(TAG, "Redmi HTTPS/WSS listening on port " + PORT);
    }

    public synchronized void stop() {
        running = false;
        if (listener != null) { try { listener.close(); } catch (IOException ignored) {} listener = null; }
        Session old = session;
        session = null;
        if (old != null) old.close();
        engine.stop();
    }

    public String status() {
        return "Server=" + (running ? "RUNNING" : "STOPPED") + " port=" + PORT +
            " call=" + currentState + " client=" + (session != null ? "connected" : "none") +
            " " + engine.metrics() + (lastError.isEmpty() ? "" : " error=" + lastError);
    }

    private void acceptLoop() {
        while (running) {
            try {
                Socket s = listener.accept();
                s.setTcpNoDelay(true); // Avoid delayed small audio TCP packets.
                s.setSendBufferSize(16 * 1024); // Limit sender backlog.
                s.setSoTimeout(10000);
                new Thread(() -> handleClient(s), "gateway-https-client").start();
            } catch (SocketTimeoutException ignored) {
            } catch (SocketException closed) {
                if (running) Log.e(TAG, "Listener failed", closed);
            } catch (Exception e) {
                if (running) { Log.e(TAG, "Accept error", e); lastError = "Listener: " + e.getMessage(); }
            }
        }
    }

    private static String readLine(InputStream in, int maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int n;
        while ((n = in.read()) != -1) {
            if (n == '\n') break;
            if (out.size() >= maxBytes) throw new IOException("Oversize HTTP header");
            if (n != '\r') out.write(n);
        }
        if (n == -1) throw new IOException("Closed during HTTP header");
        return out.toString("ISO-8859-1");
    }

    private void handleClient(Socket s) {
        try {
            InputStream input = s.getInputStream();
            OutputStream output = s.getOutputStream();
            String request = readLine(input, 2048);
            String[] parts = request.split(" ");
            if (parts.length < 3 || !"GET".equals(parts[0])) { http(output,405,"text/plain","Method not allowed".getBytes(StandardCharsets.UTF_8));return; }
            Map<String,String> headers = new HashMap<>();
            int bytes = request.length();
            for (int i = 0; i < 65; i++) {
                String h = readLine(input, 2048);
                bytes += h.length();
                if (bytes > 12000) throw new IOException("HTTP headers too large");
                if (h.isEmpty()) break;
                int colon = h.indexOf(':');
                if (colon > 0) headers.put(h.substring(0,colon).trim().toLowerCase(Locale.US),h.substring(colon+1).trim());
                if (i == 64) throw new IOException("Too many headers");
            }
            if ("/".equals(parts[1]) || "/index.html".equals(parts[1])) {
                byte[] page;
                try (InputStream asset = app.getAssets().open("gateway.html")) { page = readAll(asset, 512_000); }
                http(output,200,"text/html; charset=utf-8",page);
            } else if ("/ws".equals(parts[1]) && "websocket".equalsIgnoreCase(headers.get("upgrade"))) {
                String key = headers.get("sec-websocket-key");
                byte[] nonce;
                try { nonce = Base64.getDecoder().decode(key == null ? "" : key); }
                catch (IllegalArgumentException e) { throw new IOException("Invalid WS nonce"); }
                if (nonce.length != 16 || !"13".equals(headers.get("sec-websocket-version"))
                        || !headers.getOrDefault("connection", "").toLowerCase(Locale.US).contains("upgrade"))
                    throw new IOException("Invalid WebSocket handshake");
                String accept = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1")
                    .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
                output.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "
                    + accept + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));output.flush();
                s.setSoTimeout(45000);
                webSocket(s,input,output);
            } else http(output,404,"text/plain","Not found".getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) {
            if (running) Log.w(TAG, "Client rejected/closed: " + ex.getMessage());
        } finally {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    interface RelayFrames {
        Frame receive() throws IOException;
        void send(int opcode, byte[] payload) throws IOException;
        void close();
    }

    /** The same authenticated call/session logic is reused over encrypted Render frames. */
    void acceptEncryptedRelay(RelayFrames frames) throws IOException {
        if (!running) { frames.close(); return; }
        webSocket(new Session(frames));
    }

    private void webSocket(Socket socket,InputStream input,OutputStream output) throws IOException {
        webSocket(new Session(socket,input,output));
    }

    private void webSocket(Session peer) throws IOException {
        try {
            Frame hello = peer.receive();
            if (hello == null || hello.opcode != 1) return;
            String greeting = new String(hello.payload, StandardCharsets.UTF_8);
            if (!greeting.startsWith("AUTH ") || !secureEquals(greeting.substring(5), token)) {
                peer.writeFrame(1,"ERROR Invalid pairing token".getBytes(StandardCharsets.UTF_8));return;
            }
            synchronized (sessionLock) {
                Session replaced = session;
                if (replaced != null) replaced.close();
                engine.stop();
                session = peer;
                peer.authorized = true;
            }
            peer.startWriter();
            peer.sendText("AUTH_OK");
            peer.sendText("CLOCK " + System.currentTimeMillis());
            peer.sendText("STATE " + currentState);
            while (running && !peer.closed && session == peer) {
                Frame frame = peer.receive();
                if (frame == null) break;
                switch (frame.opcode) {
                    case 2: if ("ACTIVE".equals(currentState)) engine.offer(frame.payload); break;
                    case 1: handleCommand(peer, new String(frame.payload, StandardCharsets.UTF_8));break;
                    case 8: return;
                    case 9: peer.send(10,frame.payload);break;
                    case 10: break;
                    default: throw new IOException("Unsupported WS opcode");
                }
            }
        } catch (SocketTimeoutException e) {
            Log.i(TAG,"iPhone heartbeat timeout");
        } finally {
            synchronized (sessionLock) {
                if (session == peer) { session = null; engine.stop(); }
            }
            peer.close();
        }
    }

    private static boolean secureEquals(String candidate, String target) {
        byte[] a=candidate.getBytes(StandardCharsets.UTF_8), b=target.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(a,b);
    }

    private void handleCommand(Session s,String command) throws IOException {
        if ("PING".equals(command)) { s.sendText("PONG");return; }
        if ("STATS".equals(command)) { s.sendText("METRICS " + engine.metrics() + s.txMetrics());return; }
        if ("ANSWER".equals(command) || "END".equals(command)) {
            if (app.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
                s.sendText("ERROR Grant ANSWER_PHONE_CALLS permission on Redmi");return;
            }
            TelecomManager tel = (TelecomManager) app.getSystemService(Context.TELECOM_SERVICE);
            try {
                if ("ANSWER".equals(command)) {
                    if (!"RINGING".equals(currentState)) { s.sendText("ERROR No ringing call");return; }
                    tel.acceptRingingCall();
                    s.sendText("RESULT Answer requested; awaiting cellular state");
                } else {
                    if ("IDLE".equals(currentState)) { s.sendText("ERROR No active call");return; }
                    boolean ended = tel.endCall();
                    s.sendText(ended ? "RESULT End requested" : "ERROR Android did not end the call");
                }
            } catch (SecurityException ex) { s.sendText("ERROR Call-control permission denied"); }
            return;
        }
        s.sendText("ERROR Unknown command");
    }

    private void pollCalls() {
        String last = "";
        while (running) {
            try {
                String state = getCellularState();
                currentState = state;
                Session s = session;
                if (s != null && s.authorized && !s.closed) {
                    // If the SSL socket blocks for seconds, stale audio in TCP buffers cannot
                    // be skipped in-place; force a fresh session instead of replaying minutes.
                    if (s.isAudioWriterStalled()) {
                        lastError="Downlink socket stalled >2s; session reset";
                        Log.w(TAG,lastError);
                        s.close();
                        engine.stop();
                        Thread.sleep(300);
                        continue;
                    }
                    if (!state.equals(last)) s.sendText("STATE " + state);
                    if ("ACTIVE".equals(state)) {
                        if (!engine.isRunning() && System.currentTimeMillis() >= nextAudioAttemptMs) {
                            try { engine.start(s::sendAudio); lastError=""; }
                            catch (Exception e) { nextAudioAttemptMs=System.currentTimeMillis()+3000L; lastError="Audio: "+e.getMessage();s.sendText("ERROR "+lastError); }
                        }
                    } else if (engine.isRunning()) engine.stop();
                } else if (engine.isRunning()) engine.stop();
                last = state;
                Thread.sleep(300);
            } catch (InterruptedException ex) { Thread.currentThread().interrupt();break; }
            catch (Exception e) { lastError="Call monitor: "+e.getMessage();Log.e(TAG,"Monitor error",e); }
        }
    }

    private String getCellularState() {
        if (app.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            TelephonyManager t = (TelephonyManager) app.getSystemService(Context.TELEPHONY_SERVICE);
            switch (t.getCallState()) {
                case TelephonyManager.CALL_STATE_RINGING: return "RINGING";
                case TelephonyManager.CALL_STATE_OFFHOOK: return "ACTIVE";
                default: return "IDLE";
            }
        }
        AudioManager a = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        return a.getMode() == AudioManager.MODE_IN_CALL ? "ACTIVE" : "IDLE";
    }

    private static void http(OutputStream out,int code,String type,byte[] body) throws IOException {
        String status=code==200?"OK":code==404?"Not Found":"Method Not Allowed";
        String h="HTTP/1.1 "+code+" "+status+"\r\nContent-Type: "+type+"\r\nContent-Length: "+body.length+
              "\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.US_ASCII));out.write(body);out.flush();
    }

    private static byte[] readAll(InputStream input,int max) throws IOException {
        ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] tmp=new byte[4096];int n;
        while ((n=input.read(tmp))!=-1) { if (buf.size()+n>max) throw new IOException("Asset too large");buf.write(tmp,0,n); }
        return buf.toByteArray();
    }

    private static void fully(InputStream in,byte[] buf) throws IOException {
        int pos=0;while(pos<buf.length){int n=in.read(buf,pos,buf.length-pos);if(n<0) throw new IOException("Socket closed");pos+=n;}
    }
    static final class Frame {
        final int opcode; final byte[] payload; final long createdNs;
        Frame(int op,byte[] data){opcode=op;payload=data;createdNs=System.nanoTime();}
    }

    private static final class Session {
        final Socket socket;
        final InputStream in;
        final OutputStream out;
        final RelayFrames relayFrames;
        // Slow network never blocks the AudioRecord thread. Drop oldest audio rather than add lag.
        final ArrayBlockingQueue<Frame> sendQueue = new ArrayBlockingQueue<>(12);
        volatile long writingAudioSinceNs;
        volatile long lastAudioWriteMs;
        volatile long sentAudioFrames;
        volatile long droppedOldFrames;
        boolean isAudioWriterStalled() {
            long start=writingAudioSinceNs;
            return start!=0L && System.nanoTime()-start > 2_000_000_000L;
        }
        String txMetrics() {
            return " wsQueue="+sendQueue.size()+" wsSent="+sentAudioFrames+
                " wsOldDrops="+droppedOldFrames+" wsLastWriteMs="+lastAudioWriteMs;
        }
        volatile boolean closed;
        volatile boolean authorized;
        private Thread writer;
        Session(Socket s,InputStream input,OutputStream output){socket=s;in=input;out=output;relayFrames=null;}
        Session(RelayFrames t){socket=null;in=null;out=null;relayFrames=t;}
        void startWriter() {
            writer = new Thread(() -> {
                try {
                    while (!closed) {
                        Frame frame=sendQueue.take();
                        if (frame.opcode==2 && System.nanoTime()-frame.createdNs>500_000_000L) {
                            droppedOldFrames++;
                            continue;
                        }
                        long t=System.nanoTime();
                        if (frame.opcode==2) writingAudioSinceNs=t;
                        try {
                            writeFrame(frame.opcode,frame.payload);
                            if (frame.opcode==2) {
                                lastAudioWriteMs=(System.nanoTime()-t)/1_000_000L;
                                sentAudioFrames++;
                            }
                        } finally {writingAudioSinceNs=0L;}
                    }
                } catch (Exception e) {
                    if (!closed) Log.w(TAG,"Remote iPhone write failed: " + e.getMessage());
                } finally {close();}
            },"gateway-ws-writer");
            writer.setDaemon(true);writer.start();
        }
        Frame receive() throws IOException {
            if (relayFrames != null) return relayFrames.receive();
            int h1=in.read();if(h1<0) return null;
            int h2=in.read();if(h2<0) return null;
            int opcode=h1&15;
            if ((h1 & 128)==0 || (h1 & 112)!=0 || (h2 & 128)==0) throw new IOException("Invalid WS fragment or client mask");
            long n=h2&127;
            if (n==126) {int a=in.read(),b=in.read();if(a<0||b<0)throw new IOException("EOF");n=(a<<8)|b;}
            if (n==127) {n=0;for(int i=0;i<8;i++){int b=in.read();if(b<0)throw new IOException("EOF");n=(n<<8)|b;if(n>MAX_FRAME)throw new IOException("Oversized WS frame");}}
            if (n>MAX_FRAME) throw new IOException("Oversized WS frame");
            if (opcode>=8 && n>125) throw new IOException("Invalid WS control frame");
            byte[] mask=new byte[4], data=new byte[(int)n];fully(in,mask);fully(in,data);
            for(int i=0;i<data.length;i++)data[i]=(byte)(data[i]^mask[i&3]);
            return new Frame(opcode,data);
        }
        private void writeFrame(int opcode, byte[] data) throws IOException {
            if (closed) throw new IOException("Session disconnected");
            if (relayFrames != null) { relayFrames.send(opcode, data); return; }
            int len=data.length;
            int header=(len<126?2:len<=65535?4:10);
            byte[] raw=new byte[header+len];
            raw[0]=(byte)(128|opcode);
            if(header==2)raw[1]=(byte)len;
            else if(header==4){raw[1]=126;raw[2]=(byte)(len>>>8);raw[3]=(byte)len;}
            else {raw[1]=127;for(int i=0;i<8;i++)raw[2+i]=(byte)(((long)len) >>> (56-8*i));}
            System.arraycopy(data,0,raw,header,len);
            // One TLS write per audio frame instead of several tiny writes/records.
            out.write(raw);out.flush();
        }
        void send(int opcode,byte[] data) throws IOException {
            if (closed) throw new IOException("Session disconnected");
            Frame frame=new Frame(opcode,data);
            if(!sendQueue.offer(frame)) {
                // Favor state messages; audio frames can be dropped instead of delaying the whole call.
                if(opcode==2) {sendQueue.poll();sendQueue.offer(frame);}
                else {sendQueue.clear();sendQueue.offer(frame);}
            }
        }
        void sendText(String msg) throws IOException {send(1,msg.getBytes(StandardCharsets.UTF_8));}
        void sendAudio(byte[] pcm) throws IOException {
            // Protocol v0.5.1: SB51 + uint64 little-endian unix milliseconds + PCM16LE.
            // The browser uses the initial CLOCK response to estimate sender clock skew
            // and drops late frames instead of audibly replaying stale speech.
            byte[] data=new byte[pcm.length+12];
            data[0]='S';data[1]='B';data[2]='5';data[3]='1';
            long time=System.currentTimeMillis();
            for(int i=0;i<8;i++) data[i+4]=(byte)(time >>> (8*i));
            System.arraycopy(pcm,0,data,12,pcm.length);
            send(2,data);
        }
        void close(){closed=true;sendQueue.clear();if(writer!=null)writer.interrupt();
            if(relayFrames!=null) relayFrames.close();
            if(socket!=null) try{socket.close();}catch(Exception ignored){} }
    }

}
