package com.simbridge.audiolab;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Outbound connection to the SIM Bridge relay (relay.js on a public server).
 * The Redmi keeps one control connection open; when the relay says "NEW id", the Redmi opens a fresh
 * data connection, proves its identity with HMAC-SHA256(secret, challenge) and then hands the socket to
 * the gateway exactly as if the iPhone had connected directly. TLS stays end-to-end iPhone <-> Redmi.
 * Handshake lines are read byte by byte on purpose: nothing after the final "\n" may be consumed.
 */
final class ReverseTunnel {
    interface Sink { void accept(Socket plain) throws IOException; }

    private static final String TAG = "ReverseTunnel";
    private static volatile String state = "OFF";
    static String state() { return state; }

    private final String host, secret;
    private final int port;
    private final Sink sink;
    private volatile boolean running;
    private volatile Socket control;
    private Thread thread;

    ReverseTunnel(String host, int port, String secret, Sink sink) {
        this.host = host; this.port = port; this.secret = secret; this.sink = sink;
    }

    synchronized void start() {
        if (running) return;
        running = true;
        state = "CONNECTING";
        thread = new Thread(this::loop, "relay-control");
        thread.start();
    }

    synchronized void stop() {
        running = false;
        Socket c = control;
        if (c != null) { try { c.close(); } catch (IOException ignored) { } }
        if (thread != null) thread.interrupt();
        state = "OFF";
    }

    private void loop() {
        long backoff = 1000;
        while (running) {
            try {
                runControl();
                backoff = 1000;
            } catch (Exception e) {
                if (running) {
                    state = "ERROR: " + e.getMessage();
                    Log.w(TAG, "control connection lost: " + e);
                }
            }
            if (!running) break;
            try { Thread.sleep(backoff); } catch (InterruptedException ie) { break; }
            backoff = Math.min(backoff * 2, 30000);
        }
    }

    private void runControl() throws Exception {
        Socket c = new Socket();
        control = c;
        try {
            c.connect(new InetSocketAddress(host, port), 8000);
            c.setTcpNoDelay(true);
            c.setKeepAlive(true);
            c.setSoTimeout(45000); // the relay pings every 15s
            InputStream in = c.getInputStream();
            OutputStream out = c.getOutputStream();
            String ch = readLine(in);
            if (!ch.startsWith("CHALLENGE ")) throw new IOException("relay protocol error");
            String nonce = ch.substring(10).trim();
            write(out, "AUTH CONTROL " + hmac("CONTROL:" + nonce) + "\n");
            String ok = readLine(in);
            if (!"OK".equals(ok)) throw new IOException("relay refused the secret");
            state = "CONNECTED";
            Log.i(TAG, "connected to relay " + host + ":" + port);
            while (running) {
                String line = readLine(in);
                if ("PING".equals(line)) write(out, "PONG\n");
                else if (line.startsWith("NEW ")) {
                    final String id = line.substring(4).trim();
                    if (id.matches("[0-9a-f]{16}")) new Thread(() -> openData(id), "relay-data").start();
                }
            }
        } finally {
            try { c.close(); } catch (IOException ignored) { }
            if (running) state = "RECONNECTING";
        }
    }

    private void openData(String id) {
        Socket d = new Socket();
        try {
            d.connect(new InetSocketAddress(host, port), 8000);
            d.setTcpNoDelay(true);
            d.setSoTimeout(8000);
            InputStream in = d.getInputStream();
            OutputStream out = d.getOutputStream();
            String ch = readLine(in);
            if (!ch.startsWith("CHALLENGE ")) throw new IOException("relay protocol error");
            String nonce = ch.substring(10).trim();
            write(out, "AUTH DATA " + id + " " + hmac("DATA:" + id + ":" + nonce) + "\n");
            if (!"OK".equals(readLine(in))) throw new IOException("relay refused data connection");
            sink.accept(d);
        } catch (Exception e) {
            Log.w(TAG, "data connection failed: " + e);
            try { d.close(); } catch (IOException ignored) { }
        }
    }

    private String hmac(String message) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] raw = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : raw) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static void write(OutputStream out, String s) throws IOException {
        out.write(s.getBytes(StandardCharsets.US_ASCII));
        out.flush();
    }

    /** Reads one line without buffering past the newline. */
    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        int n;
        while ((n = in.read()) != -1) {
            if (n == '\n') break;
            if (buf.size() >= 256) throw new IOException("relay line too long");
            if (n != '\r') buf.write(n);
        }
        if (n == -1) throw new IOException("relay closed the connection");
        return buf.toString("ISO-8859-1");
    }
}
