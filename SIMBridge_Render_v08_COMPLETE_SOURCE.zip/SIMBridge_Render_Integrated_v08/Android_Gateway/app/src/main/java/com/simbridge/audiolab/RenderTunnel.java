package com.simbridge.audiolab;

import android.util.Base64;
import android.util.Log;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SNIHostName;
import java.util.Collections;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** Outbound WSS transport for a single Render Web Service (v0.8 experimental).
 * Independent AEAD keys protect application payloads from the relay's normal message inspection.
 * Browser JS is served by Render; this is not protection against a malicious HTML/JS provider.
 */
final class RenderTunnel implements GatewayServer.RelayFrames {
    private static final String TAG = "SIMBridgeRender";
    private static volatile String current = "OFF";
    static String state() { return current; }
    private static final byte[] INFO_OUT = "SIMBridge-Render-v1 gateway-to-iphone".getBytes(StandardCharsets.UTF_8);
    private static final byte[] INFO_IN = "SIMBridge-Render-v1 iphone-to-gateway".getBytes(StandardCharsets.UTF_8);
    private static final byte[] MAGIC = {'S','B','R','1'};
    private final String url, relayKey, pairingToken;
    private final GatewayServer gateway;
    private final Object sendLock = new Object();
    private volatile boolean running;
    private volatile SSLSocket socket;
    private volatile InputStream in;
    private volatile OutputStream out;
    private volatile SecretKeySpec keyOut, keyIn;
    private volatile long seqOut, seqIn;
    private Thread thread;

    RenderTunnel(String url, String relayKey, String pairingToken, GatewayServer gateway) {
        this.url=url; this.relayKey=relayKey; this.pairingToken=pairingToken; this.gateway=gateway;
    }
    synchronized void start() {
        if(running)return;
        running=true; current="CONNECTING";
        thread = new Thread(this::loop, "simbridge-render-wss");
        thread.start();
    }
    synchronized void stop() {
        running=false; current="OFF"; close();
        if(thread!=null)thread.interrupt();
    }
    private void loop() {
        int delay=1000;
        while(running) {
            try { runOnce(); delay=1000; }
            catch(Exception e){
                if(running) {
                    current="ERROR: " + e.getMessage();
                    Log.w(TAG, "Render WSS disconnected: " + e.getMessage());
                }
            } finally { close(); }
            if(!running)break;
            try{Thread.sleep(delay);}catch(InterruptedException ex){break;}
            delay=Math.min(30000,delay*2);
        }
        current="OFF";
    }
    private void runOnce() throws Exception {
        String host=url.trim().replaceFirst("^(https|wss)://", "").replaceAll("/+$", "");
        if(!host.matches("[A-Za-z0-9.-]+\\.onrender\\.com"))
            throw new IOException("Use your https://NAME.onrender.com service URL");
        SSLSocket s=(SSLSocket)SSLSocketFactory.getDefault().createSocket();
        socket=s;
        s.connect(new InetSocketAddress(host,443),8000);
        s.setTcpNoDelay(true);
        s.setSoTimeout(65000);
        SSLParameters tls=s.getSSLParameters();
        tls.setEndpointIdentificationAlgorithm("HTTPS");
        tls.setServerNames(Collections.singletonList(new SNIHostName(host)));
        s.setSSLParameters(tls);
        s.startHandshake();
        in=s.getInputStream(); out=s.getOutputStream();
        byte[] nonce=new byte[16];new SecureRandom().nextBytes(nonce);
        String nonceB64=Base64.encodeToString(nonce,Base64.NO_WRAP);
        String request="GET /ws/gateway HTTP/1.1\r\nHost: "+host+"\r\n"+
            "Upgrade: websocket\r\nConnection: Upgrade\r\n"+
            "Sec-WebSocket-Version: 13\r\nSec-WebSocket-Key: "+nonceB64+"\r\n\r\n";
        out.write(request.getBytes(StandardCharsets.US_ASCII));out.flush();
        String status=readLine(in);
        if(!status.contains(" 101 "))throw new IOException("WSS upgrade rejected: "+status);
        String acceptExpected=Base64.encodeToString(MessageDigest.getInstance("SHA-1").digest(
            (nonceB64+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)),Base64.NO_WRAP);
        String accept="";int hdrs=0;
        while(true){String h=readLine(in);if(h.isEmpty())break;if(++hdrs>40)throw new IOException("Headers too long");
            if(h.toLowerCase(Locale.US).startsWith("sec-websocket-accept:"))accept=h.substring(h.indexOf(':')+1).trim();}
        if(!acceptExpected.equals(accept))throw new IOException("WebSocket accept signature mismatch");
        JSONObject auth=new JSONObject();auth.put("type","auth");auth.put("token",relayKey);
        sendWs(1,auth.toString().getBytes(StandardCharsets.UTF_8));
        boolean accepted=false;
        long start=System.currentTimeMillis();
        while(running && !accepted){
            WsFrame f=readWs();
            if(f==null)throw new IOException("Relay closed during auth");
            if(f.opcode==1){JSONObject m=new JSONObject(new String(f.data,StandardCharsets.UTF_8));
                accepted="ready".equals(m.optString("type")) && "gateway".equals(m.optString("role"));}
            if(System.currentTimeMillis()-start>12000)throw new IOException("Relay auth timeout");
        }
        current="CONNECTED";
        Log.i(TAG,"Render relay authenticated; waiting for iPhone (no secrets logged)");
        keyOut=null;keyIn=null;seqOut=0;seqIn=-1;
        gateway.acceptEncryptedRelay(this);
    }
    private static String readLine(InputStream stream)throws IOException{
        ByteArrayOutputStream b=new ByteArrayOutputStream();int ch;
        while((ch=stream.read())!=-1){if(ch=='\n')break;if(ch!='\r')b.write(ch);if(b.size()>2048)throw new IOException("Header oversized");}
        if(ch<0)throw new IOException("EOF");return b.toString("US-ASCII");
    }
    private static final class WsFrame{
        final int opcode; final byte[] data;
        WsFrame(int op,byte[] d){opcode=op;data=d;}
    }
    private WsFrame readWs()throws IOException {
        while(running) {
            int a=in.read(),b=in.read();if(a<0||b<0)return null;
            if((a&0x80)==0 || (a&0x70)!=0 || (b&0x80)!=0)throw new IOException("Unsupported WS fragmentation/masking");
            int op=a&15;long size=b&127;
            if(size==126){int p=in.read(),q=in.read();if(p<0||q<0)throw new IOException("EOF");size=(p<<8)|q;}
            else if(size==127){size=0;for(int i=0;i<8;i++){int v=in.read();if(v<0)throw new IOException("EOF");size=(size<<8)|v;if(size>150000)throw new IOException("Frame too large");}}
            if(size>150000)throw new IOException("WS frame oversized");
            byte[] data=new byte[(int)size];readFully(in,data);
            if(op==9){sendWs(10,data);continue;}
            if(op==10)continue;
            if(op==8)return null;
            if(op!=1&&op!=2)throw new IOException("Unknown WS opcode");
            return new WsFrame(op,data);
        }
        return null;
    }
    private static void readFully(InputStream stream,byte[] bytes)throws IOException{
        int n=0;while(n<bytes.length){int k=stream.read(bytes,n,bytes.length-n);if(k<0)throw new IOException("EOF");n+=k;}
    }
    private void sendWs(int op,byte[] data)throws IOException{
        synchronized(sendLock){
            if(out==null)throw new IOException("Disconnected");
            int len=data.length;
            ByteArrayOutputStream packet=new ByteArrayOutputStream(len+24);
            packet.write(0x80|op);
            if(len<126)packet.write(0x80|len);
            else if(len<=65535){packet.write(0x80|126);packet.write((len>>>8)&255);packet.write(len&255);}
            else{packet.write(0x80|127);for(int i=7;i>=0;i--)packet.write((int)(((long)len >>> (8*i)) & 255));}
            byte[] mask=new byte[4];new SecureRandom().nextBytes(mask);packet.write(mask);
            for(int i=0;i<len;i++)packet.write(data[i]^mask[i&3]);
            out.write(packet.toByteArray());out.flush();
        }
    }
    private void acceptHello(JSONObject json)throws Exception{
        byte[] salt=Base64.decode(json.optString("salt"), Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
        if(salt.length!=16)throw new IOException("Invalid session salt");
        byte[] ikm=Base64.decode(pairingToken,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
        keyIn=new SecretKeySpec(hkdf(ikm,salt,INFO_IN),"AES");
        keyOut=new SecretKeySpec(hkdf(ikm,salt,INFO_OUT),"AES");
        seqOut=0;seqIn=-1;
    }
    private static byte[] hkdf(byte[] ikm,byte[] salt,byte[] info)throws Exception{
        Mac m=Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(salt,"HmacSHA256"));byte[] prk=m.doFinal(ikm);
        m.init(new SecretKeySpec(prk,"HmacSHA256"));
        byte[] data=Arrays.copyOf(info,info.length+1);data[info.length]=1;
        return m.doFinal(data);
    }
    private static byte[] nonce(int prefix,long seq){
        ByteBuffer b=ByteBuffer.allocate(12);b.putInt(prefix);b.putLong(seq);return b.array();
    }
    @Override public GatewayServer.Frame receive()throws IOException{
        try {
            while(running){
                WsFrame f=readWs();if(f==null)throw new IOException("Relay lost");
                if(f.opcode==1){
                    JSONObject msg=new JSONObject(new String(f.data,StandardCharsets.UTF_8));
                    String type=msg.optString("type");
                    if("peer".equals(type)){
                        if(!msg.optBoolean("online",false) && keyIn!=null)
                            throw new IOException("iPhone disconnected");
                    }else if("hello".equals(type)){
                        if(keyIn!=null)throw new IOException("Unexpected new session");
                        acceptHello(msg);
                    }
                    continue;
                }
                if(keyIn==null)continue;
                byte[] p=f.data;if(p.length<4+8+1+16||p.length>132000||
                    p[0]!='S'||p[1]!='B'||p[2]!='R'||p[3]!='1')throw new IOException("Invalid encrypted frame");
                long seq=ByteBuffer.wrap(p,4,8).getLong();
                if(seq<0||seq<=seqIn)throw new IOException("Out of order/replayed encrypted packet");
                Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE,keyIn,new GCMParameterSpec(128,nonce(0x49324741,seq)));
                cipher.updateAAD(p,0,12);
                byte[] raw=cipher.doFinal(p,12,p.length-12);
                if(raw.length<1)throw new IOException("Empty packet");
                seqIn=seq;
                int opcode=raw[0]&255;
                if(opcode!=1&&opcode!=2&&opcode!=9&&opcode!=10&&opcode!=8)throw new IOException("Invalid inner opcode");
                return new GatewayServer.Frame(opcode,Arrays.copyOfRange(raw,1,raw.length));
            }
            throw new IOException("Stopped");
        }catch(IOException e){throw e;}
        catch(Exception e){throw new IOException("Encrypted relay frame invalid",e);}
    }
    @Override public void send(int opcode,byte[] payload)throws IOException{
        try {
            if(keyOut==null)throw new IOException("No paired iPhone session");
            long seq=seqOut++;
            byte[] aad=ByteBuffer.allocate(12).put(MAGIC).putLong(seq).array();
            byte[] plain=new byte[payload.length+1];plain[0]=(byte)opcode;
            System.arraycopy(payload,0,plain,1,payload.length);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE,keyOut,new GCMParameterSpec(128,nonce(0x47324950,seq)));
            c.updateAAD(aad);
            byte[] body=c.doFinal(plain);
            byte[] packet=Arrays.copyOf(aad,aad.length+body.length);
            System.arraycopy(body,0,packet,aad.length,body.length);
            sendWs(2,packet);
        }catch(IOException e){throw e;}
        catch(Exception e){throw new IOException("Encrypted transmit failure",e);}
    }
    @Override public void close(){
        SSLSocket s=socket;socket=null;
        if(s!=null)try{s.close();}catch(IOException ignored){}
        in=null;out=null;keyIn=null;keyOut=null;
    }
}
