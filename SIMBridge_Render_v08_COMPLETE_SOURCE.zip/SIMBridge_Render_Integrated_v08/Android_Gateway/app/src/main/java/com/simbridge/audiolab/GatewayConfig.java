package com.simbridge.audiolab;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** App-private pairing token and Android Keystore-encrypted TLS keystore password. */
public final class GatewayConfig {
    private static final String PREF = "gateway_v05";
    private static final String KEY_ALIAS = "simbridge_gateway_tls_password_v1";
    private GatewayConfig() {}
    public static String token(Context context) {
        SharedPreferences prefs=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        synchronized(GatewayConfig.class) {
            String existing=prefs.getString("pair_token","");
            if(existing!=null&&!existing.isEmpty())return existing;
            byte[] random=new byte[24];new SecureRandom().nextBytes(random);
            String generated=Base64.encodeToString(random,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
            prefs.edit().putString("pair_token",generated).apply();return generated;
        }
    }
    private static SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(!store.containsAlias(KEY_ALIAS)) {
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            generator.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)store.getEntry(KEY_ALIAS,null)).getSecretKey();
    }
    public static void storePassword(Context context,String password) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] ciphertext=cipher.doFinal(password.getBytes(StandardCharsets.UTF_8));
        byte[] iv=cipher.getIV();
        byte[] payload=new byte[iv.length+ciphertext.length];
        System.arraycopy(iv,0,payload,0,iv.length);
        System.arraycopy(ciphertext,0,payload,iv.length,ciphertext.length);
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putString("password",Base64.encodeToString(payload,Base64.NO_WRAP)).apply();
    }
    public static String password(Context context) throws Exception {
        String encoded=context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("password",null);
        if(encoded==null)throw new IllegalStateException("Set TLS .p12 password first");
        byte[] data=Base64.decode(encoded,Base64.DEFAULT);
        if(data.length<29)throw new IllegalStateException("Invalid TLS password storage");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Arrays.copyOfRange(data,0,12)));
        return new String(cipher.doFinal(Arrays.copyOfRange(data,12,data.length)),StandardCharsets.UTF_8);
    }

    // ---- relay (Google Cloud) settings: address "host:port" and the shared secret ----
    private static String enc(String plain) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] ciphertext=cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] iv=cipher.getIV();
        byte[] payload=new byte[iv.length+ciphertext.length];
        System.arraycopy(iv,0,payload,0,iv.length);
        System.arraycopy(ciphertext,0,payload,iv.length,ciphertext.length);
        return Base64.encodeToString(payload,Base64.NO_WRAP);
    }
    private static String dec(String encoded) throws Exception {
        byte[] data=Base64.decode(encoded,Base64.DEFAULT);
        if(data.length<29)throw new IllegalStateException("Invalid storage");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Arrays.copyOfRange(data,0,12)));
        return new String(cipher.doFinal(Arrays.copyOfRange(data,12,data.length)),StandardCharsets.UTF_8);
    }
    public static void storeRelay(Context context,String address,String secret) throws Exception {
        SharedPreferences.Editor e=context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit();
        e.putString("relay_address",address.trim());
        if(secret!=null&&!secret.isEmpty())e.putString("relay_secret",enc(secret));
        e.apply();
    }
    public static void clearRelay(Context context){
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove("relay_address").remove("relay_secret").apply();
    }
    public static String relayAddress(Context context){
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("relay_address","");
    }
    /** Returns the decrypted secret, or "" if none is stored. */
    public static String relaySecret(Context context){
        try{
            String encoded=context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("relay_secret",null);
            return encoded==null?"":dec(encoded);
        }catch(Exception e){return "";}
    }
}
