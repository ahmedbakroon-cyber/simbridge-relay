package com.simbridge.audiolab;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import android.util.Log;

/**
 * While the call audio is bridged to the iPhone, silence the Redmi itself:
 * mute its microphone and drop the in-call (earpiece) volume to the minimum.
 * The previous values are saved in preferences and restored when the bridge stops,
 * so a crash can never leave the phone muted (HomeActivity calls restore() on resume).
 */
final class LocalSilence {
    private static final String TAG = "LocalSilence";
    private static final String PREF = "gateway_v05";
    private LocalSilence() {}

    static boolean enabled(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("local_silence", true);
    }
    static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("local_silence", on).apply();
    }

    static synchronized void apply(Context c) {
        if (!enabled(c)) return;
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (p.getBoolean("silence_applied", false)) return;
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        int vol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
        boolean mic = am.isMicrophoneMute();
        p.edit().putBoolean("silence_applied", true).putInt("saved_vol", vol).putBoolean("saved_mic", mic).commit();
        try { am.setMicrophoneMute(true); } catch (Exception e) { Log.w(TAG, "mic mute failed", e); }
        try {
            int min = Build.VERSION.SDK_INT >= 28 ? am.getStreamMinVolume(AudioManager.STREAM_VOICE_CALL) : 1;
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, min, 0);
        } catch (Exception e) { Log.w(TAG, "volume change failed", e); }
        Log.i(TAG, "Redmi silenced (saved vol=" + vol + ", mic muted before=" + mic + ")");
    }

    static synchronized void restore(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean("silence_applied", false)) return;
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        try { am.setMicrophoneMute(p.getBoolean("saved_mic", false)); } catch (Exception e) { Log.w(TAG, "mic restore failed", e); }
        try { am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, p.getInt("saved_vol", 3), 0); }
        catch (Exception e) { Log.w(TAG, "volume restore failed", e); }
        p.edit().putBoolean("silence_applied", false).commit();
        Log.i(TAG, "Redmi audio restored");
    }
}
