# SIM Bridge Redmi Gateway v0.5.1 — downlink latency hotfix

- No root/Magisk or Telegram changes.
- iOS Safari: explicitly resumes AudioContext during answer button gesture, and provides a manual sound-unlock button if iOS suspends playback.
- iOS Safari: skips replay of audio packets older than 1.2 seconds after accounting for relative client/server clock offset.
- Android: audio packets carry SB51 protocol time header; standalone v0.5.1 browser required.
- Android: WebSocket writes each frame in one TLS write, enabling TCP_NODELAY and smaller socket send buffer.
- Android: drops outbound frames stuck in its queue for >500ms and disconnects stalled socket writes >2 seconds to avoid minutes-long TCP backlog.
- More diagnosis: browser reports AudioContext state, received and stale packet counts; server reports wsQueue, wsSent, wsOldDrops, wsLastWriteMs.
- This is a SOURCE project update. It has not been verified on the user's handset. The previous v0.5 package remains available for fallback.
- Test carefully; keep Tailscale private, and do not reinstall/modify the separate Telegram application.
