#!/bin/bash
# Run on your own Mac. Generate a private TLS certificate for your Redmi Tailscale IPv4.
# Keep the private key and PKCS12 file private. Do NOT send any secrets to a chatbot.
set -euo pipefail
umask 077
if [ "$#" -ne 1 ]; then
  echo 'Usage: bash prepare_gateway_tls_mac.sh REDMI_TAILSCALE_IP'
  echo 'Example: bash prepare_gateway_tls_mac.sh 100.101.102.103'
  exit 2
fi
TAIL_IP="$1"
if ! python3 - "$TAIL_IP" <<'PY'
import ipaddress,sys
try:
 ip=ipaddress.IPv4Address(sys.argv[1])
 assert ip in ipaddress.IPv4Network('100.64.0.0/10')
except Exception:
 print('ERROR: expected the Redmi Tailscale IPv4 in 100.64.0.0/10')
 sys.exit(1)
PY
then exit 2; fi
MKCERT="$HOME/Downloads/mkcert"
if [ ! -x "$MKCERT" ]; then
  echo "ERROR: mkcert binary not executable at $MKCERT"; exit 1
fi
OUT="$HOME/Desktop/SIMBridgeGatewayTLS"
mkdir -p "$OUT"
if [ -e "$OUT/gateway.p12" ]; then
  echo 'Existing gateway.p12 found. Back it up or delete it manually before creating a replacement.'
  exit 1
fi
"$MKCERT" -cert-file "$OUT/gateway-cert.pem" -key-file "$OUT/gateway-key.pem" "$TAIL_IP"
echo
printf '%s\n' 'Next, choose a NEW strong PKCS12 export password and remember it.'
openssl pkcs12 -export -inkey "$OUT/gateway-key.pem" -in "$OUT/gateway-cert.pem" \
  -out "$OUT/gateway.p12" -name simbridge-gateway
printf '\nSUCCESS: %s\n' "$OUT/gateway.p12"
printf '%s\n' 'Copy gateway.p12 to Redmi Downloads, then import it from the SIM Bridge v0.5 app.'
printf '%s\n' 'DO NOT upload gateway-key.pem, gateway.p12 or any rootCA-key.pem to Claude or ChatGPT.'
