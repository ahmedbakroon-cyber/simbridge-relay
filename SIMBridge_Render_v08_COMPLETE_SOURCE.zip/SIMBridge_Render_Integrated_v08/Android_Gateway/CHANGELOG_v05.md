# SIM Bridge v0.5 development change log

## New Android sources
- `GatewayConfig.java`: pairing token, Android Keystore-encrypted PKCS12 password
- `GatewayService.java`: foreground service for Redmi-hosted HTTPS server
- `GatewayServer.java`: TLS 8443 HTTPS, authenticated RFC6455 WebSocket, call-state signaling and limited `ANSWER`/`END` control
- `GatewayAudioEngine.java`: VOICE_DOWNLINK + TYPE_TELEPHONY with separate capture/send/playback workers and bounded queues
- `PcmJitterBuffer.java`: bounded 20 ms audio packets with prebuffer and underrun counting
- `PcmResampler.java`: 16 kHz mono to 48 kHz stereo interpolation
- `app/src/main/assets/gateway.html`: secure iPhone Safari remote user interface

## Files altered
- `MainActivity.java`: appended v0.5 controls and `.p12` import without removing the earlier v0.4 tests
- `AndroidManifest.xml`: added gateway foreground service and call runtime permissions
- `app/build.gradle`: version updated to `0.5.0-dev`
- `gradle/wrapper/gradle-wrapper.properties`: adjusted Gradle to 8.9 to match AGP 8.7.3

## Preserved
- Existing v0.4 diagnostics and legacy WSS client remain (avoid running it simultaneously with the new gateway).
- Public CA resources copied from the original nested project; **no TLS private key is bundled**.
- Telegram companion application `SIMBridge-1.2.1` remains a separate application and is not changed.

## Verification
- Java syntax parsed: PASS (7 Java source files, no Android type resolution).
- JVM unit test of resampler and bounded jitter queue: PASS.
- XML parse and browser JavaScript syntax: PASS.
- Android SDK compilation and installation on the Redmi are **NOT YET TESTED**.
- End-to-end Tailnet TLS + Safari/Redmi audio and cellular answer/end remain **NOT YET TESTED**.
